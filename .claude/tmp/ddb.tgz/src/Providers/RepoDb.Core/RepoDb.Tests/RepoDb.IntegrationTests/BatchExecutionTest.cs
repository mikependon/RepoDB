#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using Microsoft.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RepoDb.IntegrationTests;
using RepoDb.IntegrationTests.Setup;
using System.Threading.Tasks;

namespace RepoDb.SqlServer.IntegrationTests
{
    [TestClass]
    public class BatchExecutionTest
    {
        [TestInitialize]
        public void Initialize()
        {
            Database.Initialize();
            Cleanup();
        }

        [TestCleanup]
        public void Cleanup()
        {
            Database.Cleanup();
        }

        [TestMethod]
        public async Task TestBatchExecutionForInsertAll()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        await connection.InsertAllAsync(identityTables).ConfigureAwait(false);
                        connection.UpdateAll(identityTables);
                        await connection.UpdateAllAsync(identityTables).ConfigureAwait(false);
                        connection.MergeAll(identityTables);
                        await connection.MergeAllAsync(identityTables).ConfigureAwait(false);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public void TestBatchExecutionForInsertAllSync()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        connection.InsertAll(identityTables);
                        connection.UpdateAll(identityTables);
                        connection.UpdateAll(identityTables);
                        connection.MergeAll(identityTables);
                        connection.MergeAll(identityTables);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public async Task TestBatchExecutionForUpdateAll()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize + 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        connection.UpdateAll(identityTables);
                        await connection.UpdateAllAsync(identityTables).ConfigureAwait(false);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public void TestBatchExecutionForUpdateAllSync()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize + 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        connection.UpdateAll(identityTables);
                        connection.UpdateAll(identityTables);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public async Task TestBatchExecutionForMergeAllEmptyTable()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.MergeAll(identityTables);
                        await connection.MergeAllAsync(identityTables).ConfigureAwait(false);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public void TestBatchExecutionForMergeAllEmptyTableSync()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.MergeAll(identityTables);
                        connection.MergeAll(identityTables);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public async Task TestBatchExecutionForMergeAllNonEmptyTable()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        connection.MergeAll(identityTables);
                        await connection.MergeAllAsync(identityTables).ConfigureAwait(false);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }

        [TestMethod]
        public void TestBatchExecutionForMergeAllNonEmptyTableSync()
        {
            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                var hasError = false;
                for (var i = (Constant.DefaultBatchOperationSize * 2); i > 0; i--)
                {
                    try
                    {
                        var identityTables = Helper.CreateIdentityTables(i);
                        connection.InsertAll(identityTables);
                        connection.MergeAll(identityTables);
                        connection.MergeAll(identityTables);
                    }
                    catch
                    {
                        hasError = true;
                        break;
                    }
                }
                Assert.IsFalse(hasError);
            }
        }
    }
}
