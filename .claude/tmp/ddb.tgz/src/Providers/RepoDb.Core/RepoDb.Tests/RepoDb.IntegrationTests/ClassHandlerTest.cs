#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using Microsoft.VisualStudio.TestTools.UnitTesting;
using RepoDb.Attributes;
using RepoDb.Extensions;
using RepoDb.IntegrationTests.Setup;
using RepoDb.Interfaces;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using RepoDb.IntegrationTests.Models;
using System.Data.Common;
using RepoDb.Enumerations;
using RepoDb.Exceptions;
using RepoDb.Options;
using System.Threading.Tasks;

namespace RepoDb.IntegrationTests
{
    [TestClass]
    public class ClassHandlerTest
    {
        [TestInitialize]
        public void Initialize()
        {
            Database.Initialize();
            Cleanup();
        }

        [TestCleanup]
        public void Cleanup()
        {
            Database.Cleanup();
        }

        #region Handlers

        private class ClassHandlerIdentityTableClassHandler : IClassHandler<ClassHandlerIdentityTable>
        {
            public int GetMethodCallCount { get; set; }

            public int SetMethodCallCount { get; set; }

            public ClassHandlerIdentityTable Get(ClassHandlerIdentityTable entity, ClassHandlerGetOptions options)
            {
                ++GetMethodCallCount;
                return entity;
            }

            public ClassHandlerIdentityTable Set(ClassHandlerIdentityTable entity, ClassHandlerSetOptions options)
            {
                ++SetMethodCallCount;
                return entity;
            }

            public void Reset()
            {
                GetMethodCallCount = 0;
                SetMethodCallCount = 0;
            }
        }

        private class ClassHandlerTestModelClassHandler : IClassHandler<TestModel>
        {
            public TestModel Get(TestModel entity, ClassHandlerGetOptions options)
            {
                return entity;
            }

            public TestModel Set(TestModel entity, ClassHandlerSetOptions options)
            {
                return entity;
            }
        }

        #endregion

        #region Classes

        private class TestModel { }

        [Map("[sc].[IdentityTable]"), ClassHandler(typeof(ClassHandlerIdentityTableClassHandler))]
        private class ClassHandlerIdentityTable : IdentityTable { }

        [Map("[sc].[IdentityTable]"), ClassHandler(typeof(ClassHandlerTestModelClassHandler))]
        private class ClassHandlerIdentityTableWithTestModel : IdentityTable { }

        #endregion

        #region Helpers

        private IEnumerable<ClassHandlerIdentityTable> CreateClassHandlerIdentityTables(int count)
        {
            var random = new Random();
            for (var i = 0; i < count; i++)
            {
                yield return new ClassHandlerIdentityTable
                {
                    ColumnBit = true,
                    ColumnDateTime = DateTime.UtcNow.Date,
                    ColumnDateTime2 = DateTime.UtcNow,
                    ColumnDecimal = random.Next(100),
                    ColumnFloat = random.Next(100),
                    ColumnInt = random.Next(100),
                    ColumnNVarChar = $"ColumnNvarChar-{Guid.NewGuid()}",
                    RowGuid = Guid.NewGuid()
                };
            }
        }

        private IEnumerable<ClassHandlerIdentityTableWithTestModel> CreateClassHandlerIdentityTableWithTestModels(int count)
        {
            var random = new Random();
            for (var i = 0; i < count; i++)
            {
                yield return new ClassHandlerIdentityTableWithTestModel
                {
                    ColumnBit = true,
                    ColumnDateTime = DateTime.UtcNow.Date,
                    ColumnDateTime2 = DateTime.UtcNow,
                    ColumnDecimal = random.Next(100),
                    ColumnFloat = random.Next(100),
                    ColumnInt = random.Next(100),
                    ColumnNVarChar = $"ColumnNvarChar-{Guid.NewGuid()}",
                    RowGuid = Guid.NewGuid()
                };
            }
        }

        #endregion

        #region Methods

        #region BatchQuery

        [TestMethod]
        public void TestBatchQueryWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = connection.BatchQuery<ClassHandlerIdentityTable>(page: 0,
                    rowsPerBatch: 10,
                    orderBy: OrderField.Parse(new { Id = Order.Ascending }),
                    where: (object)null);

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public async Task TestBatchQueryAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = await connection.BatchQueryAsync<ClassHandlerIdentityTable>(page: 0,
                    rowsPerBatch: 10,
                    orderBy: OrderField.Parse(new { Id = Order.Ascending }),
                    where: (object)null).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public void ThrowExceptionOnBatchQueryWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() =>
                {
                    connection.BatchQuery<ClassHandlerIdentityTableWithTestModel>(page: 0,
                        rowsPerBatch: 10,
                        orderBy: OrderField.Parse(new { Id = Order.Ascending }),
                        where: (object)null);
                });
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnBatchQueryAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () =>
                {
                    await connection.BatchQueryAsync<ClassHandlerIdentityTableWithTestModel>(page: 0,
                        rowsPerBatch: 10,
                        orderBy: OrderField.Parse(new { Id = Order.Ascending }),
                        where: (object)null).ConfigureAwait(false);
                }).ConfigureAwait(false);
            }
        }

        #endregion

        #region ExecuteQuery

        [TestMethod]
        public void TestExecuteQueryWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = connection.ExecuteQuery<ClassHandlerIdentityTable>("SELECT * FROM [sc].[IdentityTable];");

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public async Task TestExecuteQueryAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = await connection.ExecuteQueryAsync<ClassHandlerIdentityTable>("SELECT * FROM [sc].[IdentityTable];").ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public void ThrowExceptionOnExecuteQueryWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.ExecuteQuery<ClassHandlerIdentityTableWithTestModel>("SELECT * FROM [sc].[IdentityTable];"));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnExecuteQueryAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.ExecuteQueryAsync<ClassHandlerIdentityTableWithTestModel>("SELECT * FROM [sc].[IdentityTable];").ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region Merge

        [TestMethod]
        public void TestMergeWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var id = connection.Merge(table);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestMergeAsyncWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var id = await connection.MergeAsync(table).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void TestMergeManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                tables.ForEach(table => connection.Merge(table));

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestMergeAsyncManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                foreach (var table in tables)
                {
                    await connection.MergeAsync(table).ConfigureAwait(false);
                }

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnMergeWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.Merge(table));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnMergeAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.MergeAsync(table).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region MergeAll

        [TestMethod]
        public void TestMergeAllWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                connection.MergeAll(tables);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestMergeAllAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                await connection.MergeAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnMergeAllWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.MergeAll(tables));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnMergeAllAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.MergeAllAsync(tables).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region Insert

        [TestMethod]
        public void TestInsertWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var id = connection.Insert(table);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestInsertAsyncWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var id = await connection.InsertAsync(table).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void TestInsertManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                tables.ForEach(table => connection.Insert(table));

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestInsertAsyncManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                foreach (var table in tables)
                {
                    await connection.InsertAsync(table).ConfigureAwait(false);
                }

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnInsertWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.Insert(table));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnInsertAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.InsertAsync(table).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region InsertAll

        [TestMethod]
        public void TestInsertAllWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                connection.InsertAll(tables);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestInsertAllAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnInsertAllWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.InsertAll(tables));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnInsertAllAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.InsertAllAsync(tables).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region Query

        [TestMethod]
        public void TestQueryWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = connection.Insert(table);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = connection.Query<ClassHandlerIdentityTable>(id).First();

                // Assert
                Assert.AreEqual(1, handler.GetMethodCallCount);
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        [TestMethod]
        public async Task TestQueryAsyncWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = await connection.InsertAsync(table).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = (await connection.QueryAsync<ClassHandlerIdentityTable>(id).ConfigureAwait(false)).First();

                // Assert
                Assert.AreEqual(1, handler.GetMethodCallCount);
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnQueryWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.Query<ClassHandlerIdentityTableWithTestModel>(e => e.Id > 0));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnQueryAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.QueryAsync<ClassHandlerIdentityTableWithTestModel>(e => e.Id > 0).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region QueryAll

        [TestMethod]
        public void TestQueryAllWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = connection.QueryAll<ClassHandlerIdentityTable>();

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public async Task TestQueryAllAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                var result = await connection.QueryAllAsync<ClassHandlerIdentityTable>().ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.GetMethodCallCount);
                Assert.AreEqual(tables.Count, result.Count());
                result.AsList().ForEach(item =>
                {
                    var target = tables.First(t => t.Id == item.Id);
                    Helper.AssertPropertiesEquality(target, item);
                });
            }
        }

        [TestMethod]
        public void ThrowExceptionOnQueryAllWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.QueryAll<ClassHandlerIdentityTableWithTestModel>());
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnQueryAllAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.QueryAllAsync<ClassHandlerIdentityTableWithTestModel>().ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region Update

        [TestMethod]
        public void TestUpdateWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.Insert(table);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                connection.Update(table);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestUpdateAsyncWithClassHandler()
        {
            // Setup
            var table = CreateClassHandlerIdentityTables(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAsync(table).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                await connection.UpdateAsync(table).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(1, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void TestUpdateManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                tables.ForEach(table => connection.Update(table));

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestUpdateAsyncManyWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                foreach (var table in tables)
                {
                    await connection.UpdateAsync(table).ConfigureAwait(false);
                }

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnUpdateWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                Assert.Throws<InvalidTypeException>(() => connection.Insert(table));

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.Update(table));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnUpdateAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var table = CreateClassHandlerIdentityTableWithTestModels(1).First();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.InsertAsync(table).ConfigureAwait(false)).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.UpdateAsync(table).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #region UpdateAll

        [TestMethod]
        public void TestUpdateAllWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                connection.UpdateAll(tables);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public async Task TestUpdateAllAsyncWithClassHandler()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTables(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerIdentityTableClassHandler>(typeof(ClassHandlerIdentityTable));
                handler.Reset();

                // Act
                await connection.UpdateAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count, handler.SetMethodCallCount);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnUpdateAllWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                Assert.Throws<InvalidTypeException>(() => connection.InsertAll(tables));

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                Assert.Throws<InvalidTypeException>(() => connection.UpdateAll(tables));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnUpdateAllAsyncWithClassHandlerWithDifferentModel()
        {
            // Setup
            var tables = CreateClassHandlerIdentityTableWithTestModels(10).AsList();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.InsertAllAsync(tables).ConfigureAwait(false)).ConfigureAwait(false);

                // Setup
                var handler = ClassHandlerCache.Get<ClassHandlerTestModelClassHandler>(typeof(ClassHandlerIdentityTableWithTestModel));

                // Act
                await Assert.ThrowsAsync<InvalidTypeException>(async () => await connection.UpdateAllAsync(tables).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #endregion
    }
}
