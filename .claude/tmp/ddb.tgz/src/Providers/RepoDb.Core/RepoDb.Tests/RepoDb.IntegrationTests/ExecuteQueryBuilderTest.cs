#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using Microsoft.Data.SqlClient;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RepoDb.Extensions;
using RepoDb.IntegrationTests.Models;
using RepoDb.IntegrationTests.Setup;
using RepoDb.Enumerations;
using System.Collections.Generic;
using RepoDb.Exceptions;
using System.Threading.Tasks;

namespace RepoDb.IntegrationTests
{
    [TestClass]
    public class ExecuteQueryBuilderTest
    {
        [TestInitialize]
        public void Initialize()
        {
            Database.Initialize();
            Cleanup();
        }

        [TestCleanup]
        public void Cleanup()
        {
            Database.Cleanup();
        }

        #region Specialized

        #region In

        /*
         * Array
         */

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForInOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.In, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(4, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsTrue(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForInOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.In, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(4, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsTrue(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotInOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotIn, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(6, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsFalse(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotInOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotIn, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(6, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsFalse(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        /*
         * List
         */

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForInOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.In, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(4, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsTrue(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForInOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.In, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(4, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsTrue(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotInOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotIn, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(6, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsFalse(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotInOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 4, 8 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotIn, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(6, result.Count());
                result.AsList().ForEach(item =>
                {
                    Assert.IsFalse(values.Contains(item.Id));
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        #endregion

        #region Between

        /*
         * Array
         */

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForBetweenOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.Between, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForBetweenOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.Between, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaArray()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithEmptyValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = Array.Empty<long>();
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithEmptyValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = Array.Empty<long>();
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithLessValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithLessValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithMoreVaues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaArrayWithMoreVaues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new long[] { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        /*
         * List
         */

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.Between, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.Between, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void TestSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaList()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(5, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithEmptyValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long>();
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithEmptyValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long>();
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithLessValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithLessValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithMoreVaues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationViaListWithMoreVaues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var values = new List<long> { 1, 3, 7 };
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, values));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        /*
         * Shared
         */

        [TestMethod]
        public void ThrowExceptionOnSqlConnectionExecuteQueryFromQueryBuilderCreateQueryForNotBetweenOperationWithNullValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, null));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                Assert.Throws<InvalidParameterException>(() => connection.ExecuteQuery<IdentityTable>(sql, where));
            }
        }

        [TestMethod]
        public async Task ThrowExceptionOnSqlConnectionExecuteQueryAsyncFromQueryBuilderCreateQueryForNotBetweenOperationWithNullValues()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.NotBetween, null));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                await Assert.ThrowsAsync<InvalidParameterException>(async () => await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false)).ConfigureAwait(false);
            }
        }

        #endregion

        #endregion

        #region Operations

        #region Average

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateAverage()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateAverage(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<double>(sql, where);

                // Assert
                Assert.AreEqual(tables.Average(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateAverage()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateAverage(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<double>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Average(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region AverageAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateAverageAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateAverageAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = connection.ExecuteScalar<double>(sql);

                // Assert
                Assert.AreEqual(tables.Average(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateAverageAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateAverageAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = await connection.ExecuteScalarAsync<double>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Average(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region BatchQuery

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateBatchQuery()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateBatchQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    page: 2,
                    rowsPerBatch: 2,
                    orderBy: OrderField.Ascending<IdentityTable>(e => e.Id).AsEnumerable(),
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateBatchQuery()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateBatchQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    page: 2,
                    rowsPerBatch: 2,
                    orderBy: OrderField.Ascending<IdentityTable>(e => e.Id).AsEnumerable(),
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        #endregion

        #region Count

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateCount()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 4));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateCount(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<int>(sql, where);

                // Assert
                Assert.AreEqual(tables.Count(e => e.Id >= 4), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateCount()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 4));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateCount(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(e => e.Id >= 4), result);
            }
        }

        #endregion

        #region CountAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateCountAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateCountAll(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                var result = connection.ExecuteScalar<int>(sql);

                // Assert
                Assert.AreEqual(tables.Count(), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateCountAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateCountAll(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), result);
            }
        }

        #endregion

        #region Delete

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateDelete()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 4));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Assert
                Assert.AreEqual(tables.Count(), connection.CountAll<IdentityTable>());

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateDelete(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = connection.ExecuteNonQuery(sql, where);

                // Assert
                Assert.AreEqual(7, result);
                Assert.AreEqual(3, connection.CountAll<IdentityTable>());
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateDelete()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 4));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateDelete(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = await connection.ExecuteNonQueryAsync(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(7, result);
                Assert.AreEqual(3, await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));
            }
        }

        #endregion

        #region CountAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateDeleteAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Assert
                Assert.AreEqual(tables.Count(), connection.CountAll<IdentityTable>());

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateDeleteAll(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                var result = connection.ExecuteNonQuery(sql);

                // Assert
                Assert.AreEqual(tables.Count(), result);
                Assert.AreEqual(0, connection.CountAll<IdentityTable>());
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateDeleteAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateDeleteAll(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                var result = await connection.ExecuteNonQueryAsync(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), result);
                Assert.AreEqual(0, await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));
            }
        }

        #endregion

        #region Exists

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateExists()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var where = new QueryGroup(new QueryField("Id", tables.Last().Id));
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateExists(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<bool>(sql, where);

                // Assert
                Assert.IsTrue(result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateExists()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var where = new QueryGroup(new QueryField("Id", tables.Last().Id));
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateExists(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<bool>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.IsTrue(result);
            }
        }

        #endregion

        #region Insert

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateInsert()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateInsert(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var id = connection.ExecuteScalar(sql, table);

                // Assert
                Assert.IsNotNull(id);

                // Setup
                var result = connection.QueryAll<IdentityTable>().First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateInsert()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateInsert(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var id = await connection.ExecuteScalarAsync(sql, table).ConfigureAwait(false);

                // Assert
                Assert.IsNotNull(id);

                // Setup
                var result = (await connection.QueryAllAsync<IdentityTable>().ConfigureAwait(false)).First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        #endregion

        #region Max

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateMax()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMax(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<int>(sql, where);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 0).Max(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateMax()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 0));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMax(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 0).Max(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region MaxAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateMaxAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMaxAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = connection.ExecuteScalar<int>(sql);

                // Assert
                Assert.AreEqual(tables.Max(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateMaxAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMaxAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Max(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region Merge

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateMerge()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = connection.Insert(table);

                // Set the properties
                table.ColumnNVarChar = $"{table.ColumnNVarChar}-Merged";

                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMerge(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    qualifiers: fields.Where(f => dbFields.GetItems().FirstOrDefault(df => (df.IsPrimary || df.IsIdentity) && string.Equals(df.Name, f.Name, StringComparison.Ordinal)) != null),
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var affectedRow = connection.ExecuteNonQuery(sql, table);

                // Assert
                Assert.AreEqual(1, affectedRow);

                // Setup
                var result = connection.QueryAll<IdentityTable>().First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateMerge()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = await connection.InsertAsync(table).ConfigureAwait(false);

                // Set the properties
                table.ColumnNVarChar = $"{table.ColumnNVarChar}-Merged";

                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMerge(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    qualifiers: fields.Where(f => dbFields.GetItems().FirstOrDefault(df => (df.IsPrimary || df.IsIdentity) && string.Equals(df.Name, f.Name, StringComparison.Ordinal)) != null),
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var affectedRow = await connection.ExecuteNonQueryAsync(sql, table).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(1, affectedRow);

                // Setup
                var result = (await connection.QueryAllAsync<IdentityTable>().ConfigureAwait(false)).First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        #endregion

        #region Min

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateMin()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 6));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMin(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<int>(sql, where);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 6).Min(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateMin()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 6));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMin(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 6).Min(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region MinAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateMinAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMinAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = connection.ExecuteScalar<int>(sql);

                // Assert
                Assert.AreEqual(tables.Min(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateMinAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateMinAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Min(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region Query

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateQueryForIn()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.In, new[] { 4, 6 }));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateQueryForIn()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.In, new[] { 4, 6 }));
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateQueryForOr()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new[]
                {
                    new QueryField("Id", 1),
                    new QueryField("Id", 9)
                },
                Conjunction.Or);
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql, where);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateQueryForOr()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new[]
                {
                    new QueryField("Id", 1),
                    new QueryField("Id", 9)
                },
                Conjunction.Or);
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQuery(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(2, result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        #endregion

        #region QueryAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateQueryAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQueryAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields);

                // Act
                var result = connection.ExecuteQuery<IdentityTable>(sql);

                // Assert
                Assert.AreEqual(tables.Count(), result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateQueryAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateQueryAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields);

                // Act
                var result = await connection.ExecuteQueryAsync<IdentityTable>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), result.Count());
                result.AsList().ForEach(item =>
                {
                    Helper.AssertPropertiesEquality(tables.First(v => v.Id == item.Id), item);
                });
            }
        }

        #endregion

        #region Sum

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateSum()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 6));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateSum(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = connection.ExecuteScalar<int>(sql, where);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 6).Sum(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateSum()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);
            var where = new QueryGroup(new QueryField("Id", Operation.GreaterThanOrEqual, 6));

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateSum(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First(),
                    where: where);

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql, where).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Where(e => e.Id >= 6).Sum(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region SumAll

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateSumAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateSumAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = connection.ExecuteScalar<int>(sql);

                // Assert
                Assert.AreEqual(tables.Sum(e => e.ColumnInt), result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateSumAll()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateSumAll(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    field: Field.Parse<IdentityTable>(e => e.ColumnInt).First());

                // Act
                var result = await connection.ExecuteScalarAsync<int>(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Sum(e => e.ColumnInt), result);
            }
        }

        #endregion

        #region Truncate

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateTruncate()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                connection.InsertAll(tables);

                // Assert
                Assert.AreEqual(tables.Count(), connection.CountAll<IdentityTable>());

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateTruncate(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                connection.ExecuteNonQuery(sql);

                // Assert
                Assert.AreEqual(0, connection.CountAll<IdentityTable>());
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateTruncate()
        {
            // Setup
            var tables = Helper.CreateIdentityTables(10);

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                await connection.InsertAllAsync(tables).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(tables.Count(), await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));

                // Setup
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateTruncate(
                    ClassMappedNameCache.Get<IdentityTable>());

                // Act
                await connection.ExecuteNonQueryAsync(sql).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(0, await connection.CountAllAsync<IdentityTable>().ConfigureAwait(false));
            }
        }

        #endregion

        #region Update

        [TestMethod]
        public void TestSqlConnectionExecuteNonQueryFromQueryBuilderCreateUpdate()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = connection.Insert(table);

                // Set the properties
                table.ColumnNVarChar = $"{table.ColumnNVarChar}-Updated";

                // Setup
                var where = new QueryGroup(new QueryField("Id", id));

                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateUpdate(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where,
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var affectedRow = connection.ExecuteNonQuery(sql, table);

                // Assert
                Assert.AreEqual(1, affectedRow);

                // Setup
                var result = connection.QueryAll<IdentityTable>().First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionExecuteNonQueryAsyncFromQueryBuilderCreateUpdate()
        {
            // Setup
            var table = Helper.CreateIdentityTables(1).First();
            var fields = FieldCache.Get<IdentityTable>();

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act
                var id = await connection.InsertAsync(table).ConfigureAwait(false);

                // Set the properties
                table.ColumnNVarChar = $"{table.ColumnNVarChar}-Updated";

                // Setup
                var where = new QueryGroup(new QueryField("Id", id));

                // Setup
                var dbFields = DbFieldCache.Get(connection, ClassMappedNameCache.Get<IdentityTable>(), null);
                var builder = connection.GetStatementBuilder();
                var sql = builder.CreateUpdate(
                    ClassMappedNameCache.Get<IdentityTable>(),
                    fields: fields,
                    where: where,
                    primaryField: dbFields.GetPrimary(),
                    identityField: dbFields.GetIdentity());

                // Act
                var affectedRow = await connection.ExecuteNonQueryAsync(sql, table).ConfigureAwait(false);

                // Assert
                Assert.AreEqual(1, affectedRow);

                // Setup
                var result = (await connection.QueryAllAsync<IdentityTable>().ConfigureAwait(false)).First();

                // Assert
                Helper.AssertPropertiesEquality(table, result);
            }
        }

        #endregion

        #endregion
    }
}
