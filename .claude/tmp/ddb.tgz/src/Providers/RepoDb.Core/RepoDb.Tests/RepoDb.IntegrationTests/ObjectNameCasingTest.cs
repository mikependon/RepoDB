#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using Microsoft.Data.SqlClient;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RepoDb.Attributes;
using RepoDb.Extensions;
using RepoDb.IntegrationTests.Setup;
using System.Threading.Tasks;

namespace RepoDb.IntegrationTests
{
    [TestClass]
    public class ObjectNameCasingTest
    {
        [TestInitialize]
        public void Initialize()
        {
            Database.Initialize();
            Cleanup();
        }

        [TestCleanup]
        public void Cleanup()
        {
            Database.Cleanup();
        }

        #region CorrectClassNameButWithImproperCasingForClassAndFields

        private class COMPLETETABLE
        {
            [Primary]
            public Guid SESSIONID { get; set; }
            public long? COLUMNBIGINT { get; set; }
            public bool? COLUMNBIT { get; set; }
            public decimal? COLUMNINT { get; set; }
            public DateTime? COLUMNDATETIME { get; set; }
            public DateTime? COLUMNDATETIME2 { get; set; }
            public string COLUMNNVARCHAR { get; set; }
        }

        [TestMethod]
        public void TestSqlConnectionCrudWithCorrectClassNameButWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new COMPLETETABLE
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var repository = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = repository.Insert(entity);

                // Act Query
                var data = repository.Query<COMPLETETABLE>(e => e.SESSIONID == (Guid)id).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.COLUMNBIGINT);
                Assert.AreEqual(entity.COLUMNBIT, data.COLUMNBIT);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.COLUMNDATETIME2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.COLUMNDATETIME);
                Assert.AreEqual(entity.COLUMNINT, data.COLUMNINT);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.COLUMNNVARCHAR, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudWithCorrectClassNameButWithImproperCasingForClassAndFieldsAsync()
        {
            // Setup
            var entity = new COMPLETETABLE
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var repository = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await repository.InsertAsync(entity).ConfigureAwait(false);

                // Act Query
                var data = (await repository.QueryAsync<COMPLETETABLE>(e => e.SESSIONID == (Guid)id).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.COLUMNBIGINT);
                Assert.AreEqual(entity.COLUMNBIT, data.COLUMNBIT);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.COLUMNDATETIME2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.COLUMNDATETIME);
                Assert.AreEqual(entity.COLUMNINT, data.COLUMNINT);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.COLUMNNVARCHAR, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public void TestSqlConnectionCrudViaInsertAllWithCorrectClassNameButWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new COMPLETETABLE
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var repository = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = repository.InsertAll(new[] { entity });

                // Act Query
                var data = repository.Query<COMPLETETABLE>(e => e.SESSIONID == entity.SESSIONID).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.COLUMNBIGINT);
                Assert.AreEqual(entity.COLUMNBIT, data.COLUMNBIT);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.COLUMNDATETIME2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.COLUMNDATETIME);
                Assert.AreEqual(entity.COLUMNINT, data.COLUMNINT);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.COLUMNNVARCHAR, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudViaInsertAllAsyncWithCorrectClassNameButWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new COMPLETETABLE
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var repository = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await repository.InsertAllAsync(new[] { entity }).ConfigureAwait(false);

                // Act Query
                var data = (await repository.QueryAsync<COMPLETETABLE>(e => e.SESSIONID == entity.SESSIONID).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.COLUMNBIGINT);
                Assert.AreEqual(entity.COLUMNBIT, data.COLUMNBIT);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.COLUMNDATETIME2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.COLUMNDATETIME);
                Assert.AreEqual(entity.COLUMNINT, data.COLUMNINT);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.COLUMNNVARCHAR, StringComparer.Ordinal);
            }
        }

        #endregion

        #region MappedTableAndWithImproperCasingForClassAndFields

        [Map("COMPLETETABLE")]
        private class MappedTableAndWithImproperCasingForClassAndFieldsClass
        {
            [Primary]
            public Guid SessionId { get; set; }
            [Map("COLUMNBIGINT")]
            public long? ColumnBigIntMapped { get; set; }
            [Map("COLUMNBIT")]
            public bool? ColumnBitMapped { get; set; }
            [Map("COLUMNINT")]
            public decimal? ColumnIntMapped { get; set; }
            [Map("COLUMNDATETIME")]
            public DateTime? ColumnDateTimeMapped { get; set; }
            [Map("COLUMNDATETIME2")]
            public DateTime? ColumnDateTime2Mapped { get; set; }
            [Map("COLUMNNVARCHAR")]
            public string ColumnNVarCharMapped { get; set; }
        }

        [TestMethod]
        public void TestSqlConnectionCrudWithMappedTableAndWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new MappedTableAndWithImproperCasingForClassAndFieldsClass
            {
                SessionId = Guid.NewGuid(),
                ColumnBigIntMapped = long.MaxValue,
                ColumnBitMapped = true,
                ColumnDateTime2Mapped = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                ColumnDateTimeMapped = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                ColumnIntMapped = int.MaxValue,
                ColumnNVarCharMapped = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = connection.Insert(entity);

                // Act Query
                var data = connection.Query<MappedTableAndWithImproperCasingForClassAndFieldsClass>(e => e.SessionId == (Guid)id).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.ColumnBigIntMapped, data.ColumnBigIntMapped);
                Assert.AreEqual(entity.ColumnBitMapped, data.ColumnBitMapped);
                Assert.AreEqual(entity.ColumnDateTime2Mapped, data.ColumnDateTime2Mapped);
                Assert.AreEqual(entity.ColumnDateTimeMapped, data.ColumnDateTimeMapped);
                Assert.AreEqual(entity.ColumnIntMapped, data.ColumnIntMapped);
                Assert.AreEqual(entity.ColumnNVarCharMapped, data.ColumnNVarCharMapped, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudWithMappedTableAndWithImproperCasingForClassAndFieldsAsync()
        {
            // Setup
            var entity = new MappedTableAndWithImproperCasingForClassAndFieldsClass
            {
                SessionId = Guid.NewGuid(),
                ColumnBigIntMapped = long.MaxValue,
                ColumnBitMapped = true,
                ColumnDateTime2Mapped = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                ColumnDateTimeMapped = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                ColumnIntMapped = int.MaxValue,
                ColumnNVarCharMapped = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await connection.InsertAsync(entity).ConfigureAwait(false);

                // Act Query
                var data = (await connection.QueryAsync<MappedTableAndWithImproperCasingForClassAndFieldsClass>(e => e.SessionId == (Guid)id).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.ColumnBigIntMapped, data.ColumnBigIntMapped);
                Assert.AreEqual(entity.ColumnBitMapped, data.ColumnBitMapped);
                Assert.AreEqual(entity.ColumnDateTime2Mapped, data.ColumnDateTime2Mapped);
                Assert.AreEqual(entity.ColumnDateTimeMapped, data.ColumnDateTimeMapped);
                Assert.AreEqual(entity.ColumnIntMapped, data.ColumnIntMapped);
                Assert.AreEqual(entity.ColumnNVarCharMapped, data.ColumnNVarCharMapped, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public void TestSqlConnectionCrudViaInsertAllWithMappedTableAndWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new MappedTableAndWithImproperCasingForClassAndFieldsClass
            {
                SessionId = Guid.NewGuid(),
                ColumnBigIntMapped = long.MaxValue,
                ColumnBitMapped = true,
                ColumnDateTime2Mapped = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                ColumnDateTimeMapped = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                ColumnIntMapped = int.MaxValue,
                ColumnNVarCharMapped = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = connection.InsertAll(new[] { entity });

                // Act Query
                var data = connection.Query<MappedTableAndWithImproperCasingForClassAndFieldsClass>(e => e.SessionId == entity.SessionId).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.ColumnBigIntMapped, data.ColumnBigIntMapped);
                Assert.AreEqual(entity.ColumnBitMapped, data.ColumnBitMapped);
                Assert.AreEqual(entity.ColumnDateTime2Mapped, data.ColumnDateTime2Mapped);
                Assert.AreEqual(entity.ColumnDateTimeMapped, data.ColumnDateTimeMapped);
                Assert.AreEqual(entity.ColumnIntMapped, data.ColumnIntMapped);
                Assert.AreEqual(entity.ColumnNVarCharMapped, data.ColumnNVarCharMapped, StringComparer.Ordinal);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudViaInsertAllAsyncWithMappedTableAndWithImproperCasingForClassAndFields()
        {
            // Setup
            var entity = new MappedTableAndWithImproperCasingForClassAndFieldsClass
            {
                SessionId = Guid.NewGuid(),
                ColumnBigIntMapped = long.MaxValue,
                ColumnBitMapped = true,
                ColumnDateTime2Mapped = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                ColumnDateTimeMapped = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                ColumnIntMapped = int.MaxValue,
                ColumnNVarCharMapped = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await connection.InsertAllAsync(new[] { entity }).ConfigureAwait(false);

                // Act Query
                var data = (await connection.QueryAsync<MappedTableAndWithImproperCasingForClassAndFieldsClass>(e => e.SessionId == entity.SessionId).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.ColumnBigIntMapped, data.ColumnBigIntMapped);
                Assert.AreEqual(entity.ColumnBitMapped, data.ColumnBitMapped);
                Assert.AreEqual(entity.ColumnDateTime2Mapped, data.ColumnDateTime2Mapped);
                Assert.AreEqual(entity.ColumnDateTimeMapped, data.ColumnDateTimeMapped);
                Assert.AreEqual(entity.ColumnIntMapped, data.ColumnIntMapped);
                Assert.AreEqual(entity.ColumnNVarCharMapped, data.ColumnNVarCharMapped, StringComparer.Ordinal);
            }
        }

        #endregion

        #region TestSqlConnectionCrudWithImproperCasingForClassAndFieldsViaTableName

        [TestMethod]
        public void TestSqlConnectionCrudWithImproperCasingForClassAndFieldsViaTableName()
        {
            // Setup
            var entity = new
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = connection.Insert("COMPLETETABLE", entity);

                // Act Query
                var data = connection.Query("COMPLETETABLE", new { SessionId = (Guid)id }).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Update
                entity = new
                {
                    SESSIONID = entity.SESSIONID,
                    COLUMNBIGINT = long.MinValue,
                    COLUMNBIT = true,
                    COLUMNDATETIME2 = DateTime.Parse("1970-01-02 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNDATETIME = DateTime.Parse("1970-01-02 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNINT = int.MinValue,
                    COLUMNNVARCHAR = $"{Helper.GetAssemblyDescription()}-Updated"
                };

                // Act
                var rows = connection.Update("COMPLETETABLE", entity);

                // Act Query
                data = connection.Query("COMPLETETABLE", new { SessionId = (Guid)id }).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Delete
                rows = connection.Delete("COMPLETETABLE", entity.SESSIONID);

                // Act Query
                data = connection.Query("COMPLETETABLE", new { SessionId = (Guid)id }).FirstOrDefault();

                // Assert
                Assert.IsNull(data);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudWithImproperCasingForClassAndFieldsViaTableNameAsync()
        {
            // Setup
            var entity = new
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await connection.InsertAsync("COMPLETETABLE", entity).ConfigureAwait(false);

                // Act Query
                var data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = (Guid)id }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Update
                entity = new
                {
                    SESSIONID = entity.SESSIONID,
                    COLUMNBIGINT = long.MinValue,
                    COLUMNBIT = true,
                    COLUMNDATETIME2 = DateTime.Parse("1970-01-02 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNDATETIME = DateTime.Parse("1970-01-02 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNINT = int.MinValue,
                    COLUMNNVARCHAR = $"{Helper.GetAssemblyDescription()}-Updated"
                };

                // Act
                var rows = await connection.UpdateAsync("COMPLETETABLE", entity).ConfigureAwait(false);

                // Act Query
                data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = (Guid)id }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Delete
                rows = await connection.DeleteAsync("COMPLETETABLE", entity.SESSIONID).ConfigureAwait(false);

                // Act Query
                data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = (Guid)id }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNull(data);
            }
        }

        [TestMethod]
        public void TestSqlConnectionCrudViaBatchOperationsWithImproperCasingForClassAndFieldsViaTableName()
        {
            // Setup
            var entity = new
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = connection.InsertAll("COMPLETETABLE",
                    new[] { entity },
                    fields: entity.GetType().GetProperties().AsFields());

                // Act Query
                var data = connection.Query("COMPLETETABLE", new { SessionId = entity.SESSIONID }).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Update
                entity = new
                {
                    SESSIONID = entity.SESSIONID,
                    COLUMNBIGINT = long.MinValue,
                    COLUMNBIT = true,
                    COLUMNDATETIME2 = DateTime.Parse("1970-01-02 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNDATETIME = DateTime.Parse("1970-01-02 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNINT = int.MinValue,
                    COLUMNNVARCHAR = $"{Helper.GetAssemblyDescription()}-Updated"
                };

                // Act
                var rows = connection.UpdateAll("COMPLETETABLE",
                    new[] { entity },
                    fields: entity.GetType().GetProperties().AsFields());

                // Act Query
                data = connection.Query("COMPLETETABLE", new { SessionId = entity.SESSIONID }).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Delete
                rows = connection.Delete("COMPLETETABLE", entity.SESSIONID);

                // Act Query
                data = connection.Query("COMPLETETABLE", new { SessionId = entity.SESSIONID }).FirstOrDefault();

                // Assert
                Assert.IsNull(data);
            }
        }

        [TestMethod]
        public async Task TestSqlConnectionCrudViaBatchOperationsWithImproperCasingForClassAndFieldsViaTableNameAsync()
        {
            // Setup
            var entity = new
            {
                SESSIONID = Guid.NewGuid(),
                COLUMNBIGINT = long.MaxValue,
                COLUMNBIT = true,
                COLUMNDATETIME2 = DateTime.Parse("1970-01-01 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNDATETIME = DateTime.Parse("1970-01-01 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                COLUMNINT = int.MaxValue,
                COLUMNNVARCHAR = Helper.GetAssemblyDescription()
            };

            using (var connection = new SqlConnection(Database.ConnectionString))
            {
                // Act Insert
                var id = await connection.InsertAllAsync("COMPLETETABLE",
                    new[] { entity },
                    fields: entity.GetType().GetProperties().AsFields()).ConfigureAwait(false);

                // Act Query
                var data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = entity.SESSIONID }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Update
                entity = new
                {
                    SESSIONID = entity.SESSIONID,
                    COLUMNBIGINT = long.MinValue,
                    COLUMNBIT = true,
                    COLUMNDATETIME2 = DateTime.Parse("1970-01-02 1:25:00.44569", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNDATETIME = DateTime.Parse("1970-01-02 10:30:30", System.Globalization.CultureInfo.InvariantCulture),
                    COLUMNINT = int.MinValue,
                    COLUMNNVARCHAR = $"{Helper.GetAssemblyDescription()}-Updated"
                };

                // Act
                var rows = await connection.UpdateAllAsync("COMPLETETABLE",
                    new[] { entity },
                    fields: entity.GetType().GetProperties().AsFields()).ConfigureAwait(false);

                // Act Query
                data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = entity.SESSIONID }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNotNull(data);
                Assert.AreEqual(entity.COLUMNBIGINT, data.ColumnBigInt);
                Assert.AreEqual(entity.COLUMNBIT, data.ColumnBit);
                Assert.AreEqual(entity.COLUMNDATETIME2, data.ColumnDateTime2);
                Assert.AreEqual(entity.COLUMNDATETIME, data.ColumnDateTime);
                Assert.AreEqual(entity.COLUMNINT, data.ColumnInt);
                Assert.AreEqual(entity.COLUMNNVARCHAR, data.ColumnNVarChar);

                // Act Delete
                rows = await connection.DeleteAsync("COMPLETETABLE", entity.SESSIONID).ConfigureAwait(false);

                // Act Query
                data = (await connection.QueryAsync("COMPLETETABLE", new { SessionId = entity.SESSIONID }).ConfigureAwait(false)).FirstOrDefault();

                // Assert
                Assert.IsNull(data);
            }
        }

        #endregion

    }
}
