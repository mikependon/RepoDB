﻿#region Copyright Attributions

// Copyright (c) 2021 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System.Data.Common;

namespace RepoDb.Attributes.Parameter
{
    /// <summary>
    /// An attribute that is being used to define a value to the <see cref="DbParameter.Scale"/>
    /// property via a class property mapping.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="ScaleAttribute"/> class.
    /// </remarks>
    /// <param name="scale">The scale of the parameter.</param>
    [System.AttributeUsage(System.AttributeTargets.All)]
    public class ScaleAttribute(byte scale) : PropertyValueAttribute(typeof(DbParameter), nameof(DbParameter.Scale), scale)
    {

        /// <summary>
        /// Gets the mapped scale value of the parameter.
        /// </summary>
        public byte Scale => (byte)Value;
    }
}