﻿#region Copyright Attributions

// Copyright (c) 2021 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System.Data.Common;

namespace RepoDb.Attributes.Parameter
{
    /// <summary>
    /// An attribute that is being used to define a value to the <see cref="DbParameter.Size"/>
    /// property via a class property mapping.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="SizeAttribute"/> class.
    /// </remarks>
    /// <param name="size">The size of the parameter.</param>
    [System.AttributeUsage(System.AttributeTargets.All)]
    public class SizeAttribute(int size) : PropertyValueAttribute(typeof(DbParameter), nameof(DbParameter.Size), size)
    {

        /// <summary>
        /// Gets the mapped size value of the parameter.
        /// </summary>
        public int Size => (int)Value;
    }
}