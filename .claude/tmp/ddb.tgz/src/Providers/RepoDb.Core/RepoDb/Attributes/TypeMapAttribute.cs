﻿#region Copyright Attributions

// Copyright (c) 2018 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Attributes.Parameter;
using System;
using System.Data;

namespace RepoDb.Attributes
{
    /// <summary>
    /// An attribute that is used to define a mapping between the .NET CLR <see cref="Type"/> and the <see cref="System.Data.DbType"/>.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="TypeMapAttribute"/> class.
    /// </remarks>
    /// <param name="dbType">The equivalent <see cref="System.Data.DbType"/> value of the parameter.</param>
    [AttributeUsage(AttributeTargets.All)]
    public class TypeMapAttribute(DbType dbType) : DbTypeAttribute(dbType)
    {
    }
}