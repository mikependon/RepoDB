﻿#region Copyright Attributions

// Copyright (c) 2018 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

namespace RepoDb
{
    /// <summary>
    /// A class that is being used to define a mapping for the bulk insert operation.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="BulkInsertMapItem"/> object.
    /// </remarks>
    /// <param name="sourceColumn">The name of the source column or property. This respects the mapping of the properties if the source type is an entity model.</param>
    /// <param name="destinationColumn">The name of the destination column in the database.</param>
    public class BulkInsertMapItem(string sourceColumn,
        string destinationColumn)
    {

        /// <summary>
        /// Gets the name of the source column.
        /// </summary>
        public string SourceColumn { get; } = sourceColumn;

        /// <summary>
        /// Gets the name of the destination column.
        /// </summary>
        public string DestinationColumn { get; } = destinationColumn;

        /// <summary>
        /// Returns the string representation of the current object.
        /// </summary>
        /// <returns>The string representation of the current object.</returns>
        public override string ToString()
        {
            return $"Source: {SourceColumn} = Destination: {DestinationColumn}";
        }
    }
}
