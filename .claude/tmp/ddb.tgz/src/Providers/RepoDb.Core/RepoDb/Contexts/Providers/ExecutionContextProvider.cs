﻿#region Copyright Attributions

// Copyright (c) 2022 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Enumerations;
using RepoDb.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RepoDb.Contexts.Providers
{
    /// <summary>
    /// 
    /// </summary>
    internal static class ExecutionContextProvider
    {
        #region KeyColumnReturnBehavior

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entityType"></param>
        /// <param name="dbFields"></param>
        /// <returns></returns>
        public static Field GetTargetReturnColumnAsField(Type entityType,
            DbFieldCollection dbFields)
        {
            var primaryField = GetPrimaryAsReturnKeyField(entityType, dbFields);
            var identityField = GetIdentityAsReturnKeyField(entityType, dbFields);

            switch (GlobalConfiguration.Options.KeyColumnReturnBehavior)
            {
                case KeyColumnReturnBehavior.Primary:
                    return primaryField;
                case KeyColumnReturnBehavior.Identity:
                    return identityField;
                case KeyColumnReturnBehavior.PrimaryOrElseIdentity:
                    return primaryField ?? identityField;
                case KeyColumnReturnBehavior.IdentityOrElsePrimary:
                    return identityField ?? primaryField;
                default:
                    throw new InvalidOperationException(nameof(GlobalConfiguration.Options.KeyColumnReturnBehavior));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entityType"></param>
        /// <param name="dbFields"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        private static Field GetPrimaryAsReturnKeyField(Type entityType,
            DbFieldCollection dbFields)
        {
            return PrimaryCache.Get(entityType)?.AsField() ??
                dbFields?.GetPrimary()?.AsField();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entityType"></param>
        /// <param name="dbFields"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        private static Field GetIdentityAsReturnKeyField(Type entityType,
            DbFieldCollection dbFields)
        {
            return IdentityCache.Get(entityType)?.AsField() ??
                dbFields?.GetIdentity()?.AsField();
        }

        #endregion
    }
}
