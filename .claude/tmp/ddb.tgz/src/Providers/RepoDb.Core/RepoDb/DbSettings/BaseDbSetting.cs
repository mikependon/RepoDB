#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Interfaces;
using System;
using System.Data.Common;

namespace RepoDb.DbSettings
{
    /// <summary>
    /// A base class to be used when implementing an <see cref="IDbSetting"/>-based object to support a specific RDBMS data provider.
    /// </summary>
    public abstract class BaseDbSetting : IDbSetting, IEquatable<BaseDbSetting>
    {
        #region Privates

        private int? hashCode = null;

        protected BaseDbSetting()
        {
            AreTableHintsSupported = true;
            ClosingQuote = "]";
            DefaultSchema = "dbo";
            IsAffectedRowsSupported = true;
            IsDirectionSupported = true;
            IsExecuteReaderDisposable = true;
            IsMultiStatementExecutable = true;
            IsPreparable = true;
            IsTransactionSupported = true;
            IsUseUpsert = false;
            RequiresDbTypeBeforeValue = false;
            SkipsUnreferencedParameters = false;
            MaxParameterCount = 2100 - 2;
            MultiStatementSeparator = ";";
            OpeningQuote = "[";
            ParameterPrefix = "@";
            SqlTextParameterPrefix = "@";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the value that indicates whether the table hints are supported.
        /// </summary>
        public bool AreTableHintsSupported { get; protected set; }

        /// <summary>
        /// Gets the character (or string) used for closing quote.
        /// </summary>
        public string ClosingQuote { get; protected set; }

        /// <summary>
        /// Gets the default averageable .NET CLR types for the database.
        /// </summary>
        [Obsolete("This will be removed in the future releases.")]
        public Type AverageableType { get; protected set; }

        /// <summary>
        /// Gets the default schema of the database.
        /// </summary>
        public string DefaultSchema { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether the current DB Provider's <see cref="DbCommand.ExecuteNonQuery()"/>
        /// reliably reports the number of rows affected by a DML statement.
        /// </summary>
        public bool IsAffectedRowsSupported { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether setting of the value of <see cref="DbParameter.Direction"/> object is supported.
        /// </summary>
        public bool IsDirectionSupported { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether the <see cref="DbCommand"/> object must be disposed after calling the <see cref="DbCommand.ExecuteReader()"/> method.
        /// </summary>
        public bool IsExecuteReaderDisposable { get; protected set; }

        /// <summary>
        /// Gets a value whether the multiple statement execution is supported.
        /// </summary>
        public bool IsMultiStatementExecutable { get; protected set; }

        /// <summary>
        /// Gets a value that overrides <see cref="IsMultiStatementExecutable"/> specifically for whether
        /// <c>InsertAll</c> can batch more than one row into a single statement. See the remarks on
        /// <see cref="IDbSetting.IsInsertAllBatchable"/>. Left unset (<see langword="null"/>) by default,
        /// which falls back to <see cref="IsMultiStatementExecutable"/>.
        /// </summary>
        public bool? IsInsertAllBatchable { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether the current DB Provider supports the <see cref="DbCommand.Prepare()"/> calls.
        /// </summary>
        public bool IsPreparable { get; protected set; }

        /// <summary>
        /// Gets the value that indicates whether the current DB Provider's transaction support (e.g. <c>BeginTransaction()</c>)
        /// is supported.
        /// </summary>
        public bool IsTransactionSupported { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether the Insert/Update operation will be used for Merge operation.
        /// </summary>
        public bool IsUseUpsert { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether <see cref="System.Data.IDataParameter.DbType"/> must be assigned
        /// an (inferred, if not explicitly given) value before <see cref="System.Data.IDataParameter.Value"/> is
        /// set.
        /// </summary>
        public bool RequiresDbTypeBeforeValue { get; protected set; }

        /// <summary>
        /// Gets a value that indicates whether the current DB Provider strictly validates that every bound
        /// parameter is referenced by a placeholder in the generated command text.
        /// </summary> 
        public bool SkipsUnreferencedParameters { get; protected set; }

        /// <summary>
        /// Gets the maximum number of parameters/members the current DB provider allows in a single generated
        /// command text - most directly, the number of values a single <c>WHERE column IN (...)</c> clause can
        /// hold.
        /// </summary>
        public int MaxParameterCount { get; protected set; }

        /// <summary>
        /// Gets the string used to join the individual per-type command texts generated.
        /// </summary>
        public string MultiStatementSeparator { get; protected set; }

        /// <summary>
        /// Gets the character (or string) used for opening quote.
        /// </summary>
        public string OpeningQuote { get; protected set; }

        /// <summary>
        /// Gets the character (or string) used for the database command parameter quoting.
        /// </summary>
        public string ParameterPrefix { get; protected set; }

        /// <summary>
        /// Gets the character (or string) used to prefix a parameter placeholder token embedded directly into the
        /// generated SQL command text. See <see cref="RepoDb.Interfaces.IDbSetting.SqlTextParameterPrefix"/> for details.
        /// </summary>
        public string SqlTextParameterPrefix { get; protected set; }

        /// <summary>
        /// Gets the character (or string) used for separating the schema.
        /// </summary>
        [Obsolete("This will be removed in the future releases. The schema separator will be defaulted to a 'period' character.")]
        public string SchemaSeparator { get; protected set; }

        #endregion

        #region Equality and comparers

        /// <summary>
        /// Returns the hashcode for this <see cref="BaseDbSetting"/>.
        /// </summary>
        /// <returns>The hashcode value.</returns>
        public override int GetHashCode()
        {
            if (hashCode != null)
            {
                return hashCode.Value;
            }

            // AreTableHintsSupported
            hashCode = HashCode.Combine(hashCode, AreTableHintsSupported);

            // ClosingQuote
            if (!string.IsNullOrWhiteSpace(ClosingQuote))
            {
                hashCode = HashCode.Combine(hashCode, ClosingQuote);
            }

            // DefaultSchema
            if (!string.IsNullOrWhiteSpace(DefaultSchema))
            {
                hashCode = HashCode.Combine(hashCode, DefaultSchema);
            }

            // IsAffectedRowsSupported
            hashCode = HashCode.Combine(hashCode, IsAffectedRowsSupported);

            // IsDirectionSupported
            hashCode = HashCode.Combine(hashCode, IsDirectionSupported);

            // IsExecuteReaderDisposable
            hashCode = HashCode.Combine(hashCode, IsExecuteReaderDisposable);

            // IsMultiStatementExecutable
            hashCode = HashCode.Combine(hashCode, IsMultiStatementExecutable);

            // IsInsertAllBatchable
            hashCode = HashCode.Combine(hashCode, IsInsertAllBatchable);

            // IsPreparable
            hashCode = HashCode.Combine(hashCode, IsPreparable);

            // IsTransactionSupported
            hashCode = HashCode.Combine(hashCode, IsTransactionSupported);

            // IsUseUpsert
            hashCode = HashCode.Combine(hashCode, IsUseUpsert);

            // RequiresDbTypeBeforeValue
            hashCode = HashCode.Combine(hashCode, RequiresDbTypeBeforeValue);

            // SkipsUnreferencedParameters
            hashCode = HashCode.Combine(hashCode, SkipsUnreferencedParameters);

            // MaxParameterCount
            hashCode = HashCode.Combine(hashCode, MaxParameterCount);

            // OpeningQuote
            if (!string.IsNullOrWhiteSpace(OpeningQuote))
            {
                hashCode = HashCode.Combine(hashCode, OpeningQuote);
            }

            // ParameterPrefix
            if (!string.IsNullOrWhiteSpace(ParameterPrefix))
            {
                hashCode = HashCode.Combine(hashCode, ParameterPrefix);
            }

            // SqlTextParameterPrefix
            if (!string.IsNullOrWhiteSpace(SqlTextParameterPrefix))
            {
                hashCode = HashCode.Combine(hashCode, SqlTextParameterPrefix);
            }

            // MultiStatementSeparator
            if (!string.IsNullOrWhiteSpace(MultiStatementSeparator))
            {
                hashCode = HashCode.Combine(hashCode, MultiStatementSeparator);
            }

            // Set and return the hashcode
            return hashCode.Value;
        }

        /// <summary>
        /// Compares the <see cref="BaseDbSetting"/> object equality against the given target object.
        /// </summary>
        /// <param name="obj">The object to be compared to the current object.</param>
        /// <returns>True if the instances are equals.</returns>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;

            return obj.GetHashCode() == GetHashCode();
        }

        /// <summary>
        /// Compares the <see cref="BaseDbSetting"/> object equality against the given target object.
        /// </summary>
        /// <param name="other">The object to be compared to the current object.</param>
        /// <returns>True if the instances are equal.</returns>
        public bool Equals(BaseDbSetting other)
        {
            if (other is null) return false;

            return other.GetHashCode() == GetHashCode();
        }

        /// <summary>
        /// Compares the equality of the two <see cref="BaseDbSetting"/> objects.
        /// </summary>
        /// <param name="objA">The first <see cref="BaseDbSetting"/> object.</param>
        /// <param name="objB">The second <see cref="BaseDbSetting"/> object.</param>
        /// <returns>True if the instances are equal.</returns>
        public static bool operator ==(BaseDbSetting objA,
            BaseDbSetting objB)
        {
            if (objA is null)
            {
                return objB is null;
            }
            return objA.Equals(objB);
        }

        /// <summary>
        /// Compares the inequality of the two <see cref="BaseDbSetting"/> objects.
        /// </summary>
        /// <param name="objA">The first <see cref="BaseDbSetting"/> object.</param>
        /// <param name="objB">The second <see cref="BaseDbSetting"/> object.</param>
        /// <returns>True if the instances are not equal.</returns>
        public static bool operator !=(BaseDbSetting objA,
            BaseDbSetting objB) => !(objA == objB);

        #endregion
    }
}
