﻿#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using System.Linq;

namespace RepoDb.Exceptions
{
    /// <summary>
    /// An exception that is being thrown if the <see cref="Array"/> or <see cref="Enumerable"/> is empty.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="EmptyException"/> class.
    /// </remarks>
    /// <param name="message">The exception message.</param>
    public class EmptyException(string message) : Exception(message)
    {
    }
}
