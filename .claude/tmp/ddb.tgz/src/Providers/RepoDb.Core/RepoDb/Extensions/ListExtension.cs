﻿#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System.Collections.Generic;
using System.Linq;

namespace RepoDb.Extensions
{
    /// <summary>
    /// An extension class for <see cref="IList{T}"/>.
    /// </summary>
    public static class ListExtension
    {
        /// <summary>
        /// Adds an item into the <see cref="IList{T}"/> if not null.
        /// </summary>
        /// <typeparam name="T">The type of the item.</typeparam>
        /// <param name="list">The instance of the list.</param>
        /// <param name="item">The item to be evaulated and added.</param>
        public static void AddIfNotNull<T>(this IList<T> list,
            T item)
        {
            if (item != null)
            {
                list.Add(item);
            }
        }

        /// <summary>
        /// Adds an item into the <see cref="ICollection{T}"/> if not null.
        /// </summary>
        /// <typeparam name="T">The type of the item.</typeparam>
        /// <param name="list">The instance of the list.</param>
        /// <param name="items">The items to be evaulated and added.</param>
        public static void AddRangeIfNotNullOrNotEmpty<T>(this ICollection<T> list,
            IEnumerable<T> items)
        {
            if (items?.Any() == true)
            {
                foreach (var item in items)
                {
                    list.Add(item);
                }
            }
        }
    }
}
