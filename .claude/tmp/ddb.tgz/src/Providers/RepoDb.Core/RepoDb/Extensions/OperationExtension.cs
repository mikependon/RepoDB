﻿#region Copyright Attributions

// Copyright (c) 2021 SergerGood and Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using RepoDb.Enumerations;

namespace RepoDb.Extensions
{
    /// <summary>
    /// Contains the extension methods for <see cref="Operation"/>.
    /// </summary>
    public static class OperationExtension
    {
        /// <summary>
        /// Gets the text value is used to defined the <see cref="Operation"/>.
        /// </summary>
        public static string GetText(this Operation operation)
        {
            return operation switch
            {
                Operation.Equal => "=",
                Operation.NotEqual => "<>",
                Operation.LessThan => "<",
                Operation.GreaterThan => ">",
                Operation.LessThanOrEqual => "<=",
                Operation.GreaterThanOrEqual => ">=",
                Operation.Like => "LIKE",
                Operation.NotLike => "NOT LIKE",
                Operation.Between => "BETWEEN",
                Operation.NotBetween => "NOT BETWEEN",
                Operation.In => "IN",
                Operation.NotIn => "NOT IN",
                _ => throw new ArgumentOutOfRangeException(nameof(operation))
            };
        }
    }
}