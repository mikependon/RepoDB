﻿#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace RepoDb
{
    public abstract partial class BaseRepository<TEntity, TDbConnection> : IDisposable
    {

        #region Count

        /// <summary>
        /// Count the number of rows from the table.
        /// </summary>
        /// <param name="where">The dynamic expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public long Count(object where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null)
        {
            return DbRepository.Count<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Count the number of rows from the table.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public long Count(Expression<Func<TEntity, bool>> where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null)
        {
            return DbRepository.Count<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Count the number of rows from the table.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public long Count(QueryField where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null)
        {
            return DbRepository.Count<TEntity>(where: where,
                traceKey: traceKey,
				transaction: transaction,
                hints: hints);
        }

        /// <summary>
        /// Count the number of rows from the table.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public long Count(IEnumerable<QueryField> where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null)
        {
            return DbRepository.Count<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Count the number of rows from the table.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public long Count(QueryGroup where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null)
        {
            return DbRepository.Count<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Count the number of rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="where">The dynamic expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public Task<long> CountAsync(object where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.CountAsync<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Count the number of rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public Task<long> CountAsync(Expression<Func<TEntity, bool>> where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.CountAsync<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Count the number of rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public Task<long> CountAsync(QueryField where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.CountAsync<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Count the number of rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public Task<long> CountAsync(IEnumerable<QueryField> where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.CountAsync<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Count the number of rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="where">The query expression to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>An integer value that holds the number of rows from the table.</returns>
        public Task<long> CountAsync(QueryGroup where,
            string hints = null,
            string traceKey = TraceKeys.Count,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.CountAsync<TEntity>(where: where,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        #endregion

    }
}
