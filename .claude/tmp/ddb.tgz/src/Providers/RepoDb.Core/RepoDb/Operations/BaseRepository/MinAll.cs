﻿#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using System.Data;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace RepoDb
{
    public abstract partial class BaseRepository<TEntity, TDbConnection> : IDisposable
    {

        #region MinAll

        /// <summary>
        /// Computes the min value of the target field.
        /// </summary>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>The min value of the target field.</returns>
        public object MinAll(Field field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null)
        {
            return DbRepository.MinAll<TEntity>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Computes the min value of the target field.
        /// </summary>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>The min value of the target field.</returns>
        public object MinAll(Expression<Func<TEntity, object>> field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null)
        {
            return DbRepository.MinAll<TEntity>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Computes the min value of the target field in an asynchronous way.
        /// </summary>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The min value of the target field.</returns>
        public Task<object> MinAllAsync(Field field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.MinAllAsync<TEntity>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Computes the min value of the target field in an asynchronous way.
        /// </summary>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The min value of the target field.</returns>
        public Task<object> MinAllAsync(Expression<Func<TEntity, object>> field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.MinAllAsync<TEntity>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        #endregion

        #region MinAll<TResult>

        /// <summary>
        /// Computes the min value of the target field.
        /// </summary>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>The min value of the target field.</returns>
        public TResult MinAll<TResult>(Field field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null)
        {
            return DbRepository.MinAll<TEntity, TResult>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Computes the min value of the target field.
        /// </summary>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <returns>The min value of the target field.</returns>
        public TResult MinAll<TResult>(Expression<Func<TEntity, TResult>> field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null)
        {
            return DbRepository.MinAll<TEntity, TResult>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction);
        }

        /// <summary>
        /// Computes the min value of the target field in an asynchronous way.
        /// </summary>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The min value of the target field.</returns>
        public Task<TResult> MinAllAsync<TResult>(Field field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.MinAllAsync<TEntity, TResult>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Computes the min value of the target field in an asynchronous way.
        /// </summary>
        /// <typeparam name="TResult">The type of the result.</typeparam>
        /// <param name="field">The field to be minimized.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
		/// <param name="transaction">The transaction to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The min value of the target field.</returns>
        public Task<TResult> MinAllAsync<TResult>(Expression<Func<TEntity, TResult>> field,
            string hints = null,
            string traceKey = TraceKeys.MinAll,
			IDbTransaction transaction = null,
            CancellationToken cancellationToken = default)
        {
            return DbRepository.MinAllAsync<TEntity, TResult>(field: field,
                hints: hints,
                traceKey: traceKey,
				transaction: transaction,
                cancellationToken: cancellationToken);
        }

        #endregion

    }
}
