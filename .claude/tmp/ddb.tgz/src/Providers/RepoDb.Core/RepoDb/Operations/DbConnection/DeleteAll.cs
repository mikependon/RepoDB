#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Enumerations;
using RepoDb.Extensions;
using RepoDb.Interfaces;
using RepoDb.Requests;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RepoDb
{
    /// <summary>
    /// Contains the extension methods for <see cref="IDbConnection"/> object.
    /// </summary>
    public static partial class DbConnectionExtension
    {
        /*
         * The supposed maximum parameters of 2100 is not working with Microsoft.Data.SqlClient.
         * I reported this issue to SqlClient repository at Github.
         * Link: https://github.com/dotnet/SqlClient/issues/531
         *
         * The batch size used below is provider-configurable via IDbSetting.MaxParameterCount
         * (BaseDbSetting defaults it to the same 2100 - 2 this constant used to hard-code) - some
         * providers have a much lower hard limit on the number of members a single IN (...) clause
         * may hold (e.g. Firebird's DSQL parser rejects one past 1500 members outright), so a single
         * batch size can't safely be hard-coded here for every provider.
         */

        #region DeleteAll<TEntity>

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="entities">The list of data entity objects to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity>(this IDbConnection connection,
            string tableName,
            IEnumerable<TEntity> entities,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            var key = GetAndGuardPrimaryKeyOrIdentityKey(connection, tableName, transaction, GetEntityType<TEntity>(entities));
            var keys = ExtractPropertyValues<TEntity, object>(entities, PropertyCache.Get(GetEntityType<TEntity>(entities), key, includeMappings: true)).AsList();

            return DeleteAllInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <typeparam name="TKey">The type of the key column.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity, TKey>(this IDbConnection connection,
            string tableName,
            IEnumerable<TKey> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            return DeleteAllInternal(connection: connection,
                tableName: tableName,
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity>(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            return DeleteAllInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="entities">The list of data entity objects to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity>(this IDbConnection connection,
            IEnumerable<TEntity> entities,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            var key = GetAndGuardPrimaryKeyOrIdentityKey(GetEntityType<TEntity>(entities), connection, transaction);
            var keys = ExtractPropertyValues<TEntity, object>(entities, PropertyCache.Get(GetEntityType<TEntity>(entities), key, includeMappings: true))?.AsList();

            return DeleteAllInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <typeparam name="TKey">The type of the key column.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity, TKey>(this IDbConnection connection,
            IEnumerable<TKey> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            return DeleteAllInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity>(this IDbConnection connection,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            return DeleteAllInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll<TEntity>(this IDbConnection connection,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            return DeleteAllInternal<TEntity>(connection: connection,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static int DeleteAllInternal<TEntity>(this IDbConnection connection,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
            where TEntity : class
        {
            // Variables
            var request = new DeleteAllRequest(typeof(TEntity),
                connection,
                transaction,
                hints,
                statementBuilder);

            // Return the result
            return DeleteAllInternalBase(connection: connection,
                request: request,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace);
        }

        #endregion

        #region DeleteAllAsync<TEntity>

        /// <summary>
        /// Delete the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="entities">The list of data entity objects to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static async Task<int> DeleteAllAsync<TEntity>(this IDbConnection connection,
            string tableName,
            IEnumerable<TEntity> entities,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            var key = await GetAndGuardPrimaryKeyOrIdentityKeyAsync(connection, tableName, transaction, GetEntityType(entities), cancellationToken).ConfigureAwait(false);
            var keys = ExtractPropertyValues<TEntity, object>(entities, PropertyCache.Get<TEntity>(key, includeMappings: true)).AsList();

            return await DeleteAllAsyncInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        /// <summary>
        /// Delete the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <typeparam name="TKey">The type of the key column.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync<TEntity, TKey>(this IDbConnection connection,
            string tableName,
            IEnumerable<TKey> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: tableName,
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync<TEntity>(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="entities">The list of data entity objects to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static async Task<int> DeleteAllAsync<TEntity>(this IDbConnection connection,
            IEnumerable<TEntity> entities,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            var key = await GetAndGuardPrimaryKeyOrIdentityKeyAsync(GetEntityType(entities), connection, transaction, cancellationToken).ConfigureAwait(false);
            var keys = ExtractPropertyValues<TEntity, object>(entities, PropertyCache.Get<TEntity>(key, includeMappings: true))?.AsList();

            return await DeleteAllAsyncInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <typeparam name="TKey">The type of the key column.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync<TEntity, TKey>(this IDbConnection connection,
            IEnumerable<TKey> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys?.WithType<object>(),
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync<TEntity>(this IDbConnection connection,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: ClassMappedNameCache.Get<TEntity>(),
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync<TEntity>(this IDbConnection connection,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            return DeleteAllAsyncInternal<TEntity>(connection: connection,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <typeparam name="TEntity">The type of the data entity.</typeparam>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static Task<int> DeleteAllAsyncInternal<TEntity>(this IDbConnection connection,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
            where TEntity : class
        {
            // Variables
            var request = new DeleteAllRequest(typeof(TEntity),
                connection,
                transaction,
                hints,
                statementBuilder);

            // Return the result
            return DeleteAllAsyncInternalBase(connection: connection,
                request: request,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                cancellationToken: cancellationToken);
        }

        #endregion

        #region DeleteAll(TableName)

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
        {
            return DeleteAllInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static int DeleteAll(this IDbConnection connection,
            string tableName,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
        {
            return DeleteAllInternal(connection: connection,
                tableName: tableName,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder);
        }

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static int DeleteAllInternal(this IDbConnection connection,
            string tableName,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
        {
            // Variables
            var request = new DeleteAllRequest(tableName,
                connection,
                transaction,
                hints,
                statementBuilder);

            // Return the result
            return DeleteAllInternalBase(connection: connection,
                request: request,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace);
        }

        /// <summary>
        /// Delete the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static int DeleteAllInternal(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null)
        {
            var key = GetAndGuardPrimaryKeyOrIdentityKey(connection, tableName, transaction);
            var dbSetting = connection.GetDbSetting();
            var hasImplicitTransaction = false;
            var count = keys?.AsList()?.Count;
            var deletedRows = 0;

            try
            {
                // Creates a transaction (if needed)
                if (transaction == null && count > dbSetting.MaxParameterCount && dbSetting.IsTransactionSupported)
                {
                    transaction = connection.EnsureOpen().BeginTransaction();
                    hasImplicitTransaction = true;
                }

                // Call the underlying method
                var splitted = keys?.Split(dbSetting.MaxParameterCount).AsList();
                if (splitted?.Any() == true)
                {
                    foreach (var keyValues in splitted)
                    {
                        if (!keyValues.Any())
                        {
                            break;
                        }
                        var field = new QueryField(key.Name, Operation.In, keyValues.AsList(), dbType: null, prependUnderscore: false);
                        deletedRows += DeleteInternal(connection: connection,
                            tableName: tableName,
                            where: new QueryGroup(field),
                            hints: hints,
                            commandTimeout: commandTimeout,
                            traceKey: traceKey,
                            transaction: transaction,
                            trace: trace,
                            statementBuilder: statementBuilder);
                    }
                }

                // Commit the transaction
                if (hasImplicitTransaction)
                {
                    transaction?.Commit();
                }

            }
            finally
            {
                // Dispose the transaction
                if (hasImplicitTransaction)
                {
                    transaction?.Dispose();
                }
            }

            // Return the value
            return deletedRows;
        }

        #endregion

        #region DeleteAllAsync(TableName)

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: tableName,
                keys: keys,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static Task<int> DeleteAllAsync(this IDbConnection connection,
            string tableName,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
        {
            return DeleteAllAsyncInternal(connection: connection,
                tableName: tableName,
                hints: hints,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                statementBuilder: statementBuilder,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static Task<int> DeleteAllAsyncInternal(this IDbConnection connection,
            string tableName,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
        {
            // Variables
            var request = new DeleteAllRequest(tableName,
                connection,
                transaction,
                hints,
                statementBuilder);

            // Return the result
            return DeleteAllAsyncInternalBase(connection: connection,
                request: request,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                cancellationToken: cancellationToken);
        }

        /// <summary>
        /// Delete all the rows from the table in an asynchronous way.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="tableName">The name of the target table.</param>
        /// <param name="keys">The list of the keys to be deleted.</param>
        /// <param name="hints">The table hints to be used.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="statementBuilder">The statement builder object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        public static async Task<int> DeleteAllAsyncInternal(this IDbConnection connection,
            string tableName,
            IEnumerable<object> keys,
            string hints = null,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            IStatementBuilder statementBuilder = null,
            CancellationToken cancellationToken = default)
        {
            var key = await GetAndGuardPrimaryKeyOrIdentityKeyAsync(connection, tableName, transaction, cancellationToken).ConfigureAwait(false);
            var dbSetting = connection.GetDbSetting();
            var hasImplicitTransaction = false;
            var count = keys?.AsList()?.Count;
            var deletedRows = 0;

            try
            {
                // Creates a transaction (if needed)
                if (transaction == null && count > dbSetting.MaxParameterCount && dbSetting.IsTransactionSupported)
                {
                    transaction = (await connection.EnsureOpenAsync(cancellationToken).ConfigureAwait(false)).BeginTransaction();
                    hasImplicitTransaction = true;
                }

                // Call the underlying method
                var splitted = keys?.Split(dbSetting.MaxParameterCount).AsList();
                if (splitted?.Any() == true)
                {
                    foreach (var keyValues in splitted)
                    {
                        if (!keyValues.Any())
                        {
                            break;
                        }
                        var field = new QueryField(key.Name, Operation.In, keyValues.AsList(), dbType: null, prependUnderscore: false);
                        deletedRows += await DeleteAsyncInternal(connection: connection,
                            tableName: tableName,
                            where: new QueryGroup(field),
                            hints: hints,
                            commandTimeout: commandTimeout,
                traceKey: traceKey,
                            transaction: transaction,
                            trace: trace,
                            statementBuilder: statementBuilder,
                            cancellationToken: cancellationToken).ConfigureAwait(false);
                    }
                }

                // Commit the transaction
                if (hasImplicitTransaction)
                {
                    transaction?.Commit();
                }

            }
            finally
            {
                // Dispose the transaction
                if (hasImplicitTransaction)
                {
                    transaction?.Dispose();
                }
            }

            // Return the value
            return deletedRows;
        }

        #endregion

        #region DeleteAllInternalBase

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="request">The actual <see cref="DeleteAllRequest"/> object.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static int DeleteAllInternalBase(this IDbConnection connection,
            DeleteAllRequest request,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null)
        {
            // Variables
            var commandType = CommandType.Text;
            var commandText = CommandTextCache.GetDeleteAllText(request);
            var dbSetting = connection.GetDbSetting();
            var affectedRowsFallback = !dbSetting.IsAffectedRowsSupported ?
                (int?)connection.CountAllInternal(tableName: request.Name,
                    hints: request.Hints,
                    commandTimeout: commandTimeout,
                    traceKey: traceKey,
                    transaction: transaction,
                    trace: trace,
                    statementBuilder: request.StatementBuilder) :
                null;

            // Actual Execution
            var result = ExecuteNonQueryInternal(connection: connection,
                commandText: commandText,
                param: null,
                commandType: commandType,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                entityType: request.Type,
                dbFields: DbFieldCache.Get(connection, request.Name, transaction, enableValidation: true),
                skipCommandArrayParametersCheck: true);

            // Result
            return affectedRowsFallback ?? result;
        }

        #endregion

        #region DeleteAllAsyncInternalBase

        /// <summary>
        /// Delete all the rows from the table.
        /// </summary>
        /// <param name="connection">The connection object to be used.</param>
        /// <param name="request">The actual <see cref="DeleteAllRequest"/> object.</param>
        /// <param name="traceKey">The tracing key to be used.</param>
        /// <param name="commandTimeout">The command timeout in seconds to be used.</param>
        /// <param name="transaction">The transaction to be used.</param>
        /// <param name="trace">The trace object to be used.</param>
        /// <param name="cancellationToken">The <see cref="CancellationToken"/> object to be used during the asynchronous operation.</param>
        /// <returns>The number of rows that has been deleted from the table.</returns>
        internal static async Task<int> DeleteAllAsyncInternalBase(this IDbConnection connection,
            DeleteAllRequest request,
            int? commandTimeout = null,
            string traceKey = TraceKeys.DeleteAll,
            IDbTransaction transaction = null,
            ITrace trace = null,
            CancellationToken cancellationToken = default)
        {
            // Variables
            var commandType = CommandType.Text;
            var commandText = CommandTextCache.GetDeleteAllText(request);
            var dbSetting = connection.GetDbSetting();
            var affectedRowsFallback = !dbSetting.IsAffectedRowsSupported ?
                (int?)await connection.CountAllAsyncInternal(tableName: request.Name,
                    hints: request.Hints,
                    commandTimeout: commandTimeout,
                    traceKey: traceKey,
                    transaction: transaction,
                    trace: trace,
                    statementBuilder: request.StatementBuilder,
                    cancellationToken: cancellationToken).ConfigureAwait(false) :
                null;

            // Actual Execution
            var result = await ExecuteNonQueryAsyncInternal(connection: connection,
                commandText: commandText,
                param: null,
                commandType: commandType,
                commandTimeout: commandTimeout,
                traceKey: traceKey,
                transaction: transaction,
                trace: trace,
                cancellationToken: cancellationToken,
                entityType: request.Type,
                dbFields: await DbFieldCache.GetAsync(connection, request.Name, transaction, enableValidation: true, cancellationToken).ConfigureAwait(false),
                skipCommandArrayParametersCheck: true).ConfigureAwait(false);

            // Result
            return affectedRowsFallback ?? result;
        }

        #endregion
    }
}
