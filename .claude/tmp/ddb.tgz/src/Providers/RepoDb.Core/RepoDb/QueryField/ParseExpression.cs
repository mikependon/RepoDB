﻿#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Enumerations;
using RepoDb.Exceptions;
using RepoDb.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace RepoDb
{
    public partial class QueryField
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="field"></param>
        /// <returns></returns>
        private static ClassProperty GetTargetProperty<TEntity>(Field field)
            where TEntity : class
        {
            var properties = PropertyCache.Get<TEntity>();

            // Failing at some point - for base interfaces
            var property = properties
                .FirstOrDefault(p =>
                    string.Equals(p.GetMappedName(), field.Name, StringComparison.OrdinalIgnoreCase));

            // Matches to the actual class properties
            if (property == null)
            {
                property = properties
                    .FirstOrDefault(p =>
                        string.Equals(p.PropertyInfo.Name, field.Name, StringComparison.OrdinalIgnoreCase));
            }

            // Return the value
            return property;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expressionType"></param>
        /// <returns></returns>
        internal static Operation GetOperation(ExpressionType expressionType)
        {
            return expressionType switch
            {
                ExpressionType.Equal => Operation.Equal,
                ExpressionType.GreaterThan => Operation.GreaterThan,
                ExpressionType.LessThan => Operation.LessThan,
                ExpressionType.NotEqual => Operation.NotEqual,
                ExpressionType.GreaterThanOrEqual => Operation.GreaterThanOrEqual,
                ExpressionType.LessThanOrEqual => Operation.LessThanOrEqual,
                _ => throw new NotSupportedException($"Operation: Expression '{expressionType}' is currently not supported.")
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="enumerable"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        private static QueryField ToIn(string fieldName,
            System.Collections.IEnumerable enumerable,
            ExpressionType? unaryNodeType = null)
        {
            var operation = unaryNodeType == ExpressionType.Not ? Operation.NotIn : Operation.In;
            return new QueryField(fieldName, operation, enumerable.WithType<object>().AsArray(), dbType: null, prependUnderscore: false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="enumerable"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        private static IEnumerable<QueryField> ToQueryFields(string fieldName,
            System.Collections.IEnumerable enumerable,
            ExpressionType? unaryNodeType = null)
        {
            var operation = (unaryNodeType == ExpressionType.Not || unaryNodeType == ExpressionType.NotEqual) ?
                Operation.NotEqual : Operation.Equal;
            foreach (var item in enumerable)
            {
                yield return new QueryField(fieldName, operation, item, dbType: null, prependUnderscore: false);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="value"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        private static QueryField ToLike(string fieldName,
            object value,
            ExpressionType? unaryNodeType = null)
        {
            var operation = unaryNodeType == ExpressionType.Not ? Operation.NotLike : Operation.Like;
            return new QueryField(fieldName, operation, value, dbType: null, prependUnderscore: false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string ConvertToLikeableValue(string methodName,
            string value)
        {
            if (string.Equals(methodName, "Contains", StringComparison.Ordinal))
            {
                value = value.StartsWith("%", StringComparison.OrdinalIgnoreCase) ? value : string.Concat("%", value);
                value = value.EndsWith("%", StringComparison.OrdinalIgnoreCase) ? value : string.Concat(value, "%");
            }
            else if (string.Equals(methodName, "StartsWith", StringComparison.Ordinal))
            {
                value = value.EndsWith("%", StringComparison.OrdinalIgnoreCase) ? value : string.Concat(value, "%");
            }
            else if (string.Equals(methodName, "EndsWith", StringComparison.Ordinal))
            {
                value = value.StartsWith("%", StringComparison.OrdinalIgnoreCase) ? value : string.Concat("%", value);
            }
            return value;
        }

        /*
         * Binary
         */

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static IEnumerable<QueryField> Parse<TEntity>(BinaryExpression expression)
            where TEntity : class
        {
            // Only support the following expression type
            if (!expression.IsExtractable())
            {
                throw new NotSupportedException($"Expression '{expression}' is currently not supported.");
            }

            // Field
            var field = expression.GetField();
            var property = GetTargetProperty<TEntity>(field);

            // Check
            if (property == null)
            {
                throw new InvalidExpressionException($"Invalid expression '{expression}'. The property {field.Name} is not defined on a target type '{typeof(TEntity).FullName}'.");
            }
            else
            {
                field = property.AsField();
            }

            // Value
            var value = expression.GetValue();

            // Operation
            var operation = GetOperation(expression.NodeType);

            // Enum
            if (property.PropertyInfo.PropertyType.IsEnum)
            {
                value = ToEnumValue(property.PropertyInfo.PropertyType, value);
            }

            // Return the value
            return new QueryField(field, operation, value, dbType: null, prependUnderscore: false).AsEnumerable();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="enumType"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static object ToEnumValue(Type enumType,
            object value)
        {
            return (value != null ?
                ToEnumValue(enumType, Enum.GetName(enumType, value)) : null) ?? value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="enumType"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        private static object ToEnumValue(Type enumType,
            string name)
        {
            return !string.IsNullOrEmpty(name) && Enum.IsDefined(enumType, name) ?
                Enum.Parse(enumType, name) : null;
        }

        /*
         * Member
         */

        internal static IEnumerable<QueryField> Parse<TEntity>(MemberExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Operation
            var operation = unaryNodeType == ExpressionType.Not ? Operation.NotEqual : Operation.Equal;

            // Value
            object value;
            if (expression.Type == StaticType.Boolean)
            {
                value = true;
            }
            else
            {
                value = expression.GetValue();
            }

            // Return
            return new QueryField(property.GetMappedName(), operation, value, dbType: null, prependUnderscore: false).AsEnumerable();
        }

        /*
         * MethodCall
         */

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static IEnumerable<QueryField> Parse<TEntity>(MethodCallExpression expression,
        ExpressionType? unaryNodeType = null)
        where TEntity : class
        {
            if (string.Equals(expression.Method.Name, "Equals", StringComparison.Ordinal))
            {
                return ParseEquals<TEntity>(expression, unaryNodeType)?.AsEnumerable();
            }
            else if (string.Equals(expression.Method.Name, "CompareString", StringComparison.Ordinal))
            {
                // Usual case for VB.Net (Microsoft.VisualBasic.CompilerServices.Operators.CompareString #767)
                return ParseCompareString<TEntity>(expression, unaryNodeType)?.AsEnumerable();
            }
            else if (string.Equals(expression.Method.Name, "Contains", StringComparison.Ordinal))
            {
                return ParseContains<TEntity>(expression, unaryNodeType)?.AsEnumerable();
            }
            else if (string.Equals(expression.Method.Name, "StartsWith", StringComparison.Ordinal) ||
string.Equals(expression.Method.Name, "EndsWith", StringComparison.Ordinal))
            {
                return ParseWith<TEntity>(expression, unaryNodeType)?.AsEnumerable();
            }
            else if (string.Equals(expression.Method.Name, "All", StringComparison.Ordinal))
            {
                return ParseAll<TEntity>(expression, unaryNodeType);
            }
            else if (string.Equals(expression.Method.Name, "Any", StringComparison.Ordinal))
            {
                return ParseAny<TEntity>(expression, unaryNodeType)?.AsEnumerable();
            }
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static QueryField ParseEquals<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Value
            if (expression?.Object != null)
            {
                if (expression.Object?.Type == StaticType.String)
                {
                    var value = Converter.ToType<string>(expression.Arguments.First().GetValue());
                    return new QueryField(property.GetMappedName(), value);
                }
            }

            // Return
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static QueryField ParseCompareString<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = expression.Arguments.First().ToMember().Member;

            // Value
            var value = Converter.ToType<string>(expression.Arguments.ElementAt(1).GetValue());

            // Return
            return new QueryField(property.GetMappedName(), value);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static QueryField ParseContains<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Value
            if (expression?.Object != null)
            {
                if (expression.Object?.Type == StaticType.String)
                {
                    var likeable = ConvertToLikeableValue("Contains", Converter.ToType<string>(expression.Arguments.First().GetValue()));
                    return ToLike(property.GetMappedName(), likeable, unaryNodeType);
                }
                else
                {
                    var enumerable = Converter.ToType<System.Collections.IEnumerable>(expression.Object.GetValue());
                    return ToIn(property.GetMappedName(), enumerable, unaryNodeType);
                }
            }
            else
            {
                // In .NET 10, array.Contains(e.Property) compiles to MemoryExtensions.Contains(span, value, comparer).
                // The first argument is a ReadOnlySpan conversion of the source collection. Try each argument in
                // order until we find one that produces an IEnumerable (unwrapping span conversions if needed).
                System.Collections.IEnumerable enumerable = null;
                foreach (var arg in expression.Arguments)
                {
                    var candidate = GetEnumerableValue(arg);
                    if (candidate != null)
                    {
                        enumerable = candidate;
                        break;
                    }
                }
                return ToIn(property.GetMappedName(), enumerable, unaryNodeType);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static QueryField ParseWith<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Values
            var value = Converter.ToType<string>(expression.Arguments.First().GetValue());

            // Fields
            return ToLike(property.GetMappedName(),
                ConvertToLikeableValue(expression.Method.Name, value), unaryNodeType);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static IEnumerable<QueryField> ParseAll<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Value
            var enumerable = Converter.ToType<System.Collections.IEnumerable>(expression.Arguments.First().GetValue());
            return ToQueryFields(property.GetMappedName(), enumerable, unaryNodeType);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="expression"></param>
        /// <param name="unaryNodeType"></param>
        /// <returns></returns>
        internal static IEnumerable<QueryField> ParseAny<TEntity>(MethodCallExpression expression,
            ExpressionType? unaryNodeType = null)
            where TEntity : class
        {
            // Property
            var property = GetProperty<TEntity>(expression);

            // Value
            var enumerable = Converter.ToType<System.Collections.IEnumerable>(expression.Arguments.First().GetValue());
            return ToQueryFields(property.GetMappedName(), enumerable, unaryNodeType);
        }

        #region GetEnumerableValue

        // Tries to extract an IEnumerable from an expression argument. In .NET 10, array.Contains()
        // compiles to MemoryExtensions.Contains(span_conversion, value, comparer), so the first
        // argument is a method call returning ReadOnlySpan. We unwrap span conversions to reach
        // the underlying array/collection argument.
        private static System.Collections.IEnumerable GetEnumerableValue(Expression expression)
        {
            if (expression is MethodCallExpression call)
            {
                // Unwrap span-producing methods (e.g., Array.AsSpan, MemoryExtensions.AsSpan)
                // by looking at their first argument recursively.
                if (call.Type.IsGenericType &&
                    call.Type.GetGenericTypeDefinition() == typeof(ReadOnlySpan<>))
                {
                    var spanArg = call.Arguments.FirstOrDefault() ?? call.Object;
                    if (spanArg != null)
                        return GetEnumerableValue(spanArg);
                    return null;
                }
            }

            var value = expression.GetValue();
            return value is System.Collections.IEnumerable e ? e : null;
        }

        #endregion

        #region GetProperty

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(Expression expression)
            where TEntity : class
        {
            return expression switch
            {
                null => null,
                LambdaExpression lambdaExpression => GetProperty<TEntity>(lambdaExpression),
                BinaryExpression binaryExpression => GetProperty<TEntity>(binaryExpression),
                MethodCallExpression methodCallExpression => GetProperty<TEntity>(methodCallExpression),
                MemberExpression memberExpression => GetProperty<TEntity>(memberExpression),
                UnaryExpression unaryExpression => GetProperty<TEntity>(unaryExpression.Operand),
                _ => null
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(LambdaExpression expression)
            where TEntity : class
        {
            return GetProperty<TEntity>(expression.Body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(BinaryExpression expression)
            where TEntity : class
        {
            return GetProperty<TEntity>(expression.Left) ?? GetProperty<TEntity>(expression.Right);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(MethodCallExpression expression)
            where TEntity : class
        {
            return expression?.Object?.Type == StaticType.String ?
            GetProperty<TEntity>(expression.Object.ToMember()) :
            expression?.Arguments
                .Select(a => GetProperty<TEntity>(a))
                .FirstOrDefault(p => p != null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(MemberExpression expression)
            where TEntity : class
        {
            return expression.Member is PropertyInfo pi ? GetProperty<TEntity>(pi) : null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="propertyInfo"></param>
        /// <returns></returns>
        internal static ClassProperty GetProperty<TEntity>(PropertyInfo propertyInfo)
            where TEntity : class
        {
            if (propertyInfo == null)
            {
                return null;
            }

            // Variables
            var properties = PropertyCache.Get<TEntity>();
            var name = PropertyMappedNameCache.Get(propertyInfo);

            // Failing at some point - for base interfaces
            var property = properties
                .FirstOrDefault(p =>
                    string.Equals(p.GetMappedName(), name, StringComparison.OrdinalIgnoreCase));

            // Matches to the actual class properties
            if (property == null)
            {
                property = properties
                    .FirstOrDefault(p =>
                        string.Equals(p.PropertyInfo.Name, name, StringComparison.OrdinalIgnoreCase));
            }

            // Return the value
            return property;
        }

        #endregion
    }
}
