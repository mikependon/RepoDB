#region Copyright Attributions

// Copyright (c) 2018 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using RepoDb.Enumerations;
using RepoDb.Extensions;
using RepoDb.Interfaces;

namespace RepoDb
{
    /// <summary>
    /// A widely-used class for defining the groupings when composing the query expression. This object is used by most operations
    /// to define the filters and expressions on the actual execution.
    /// </summary>
    /// <remarks>
    /// Creates a new instance of <see cref="QueryGroup"/> object.
    /// </remarks>
    /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
    /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
    /// <param name="conjunction">The conjunction to be used for every group separation.</param>
    /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
    public partial class QueryGroup(IEnumerable<QueryField> queryFields,
        IEnumerable<QueryGroup> queryGroups,
        Conjunction conjunction,
        bool isNot) : IEquatable<QueryGroup>
    {
        private bool isFixed = false;
        private int? hashCode = null;
        private List<QueryField> traversedQueryFields;

        #region Constructors

        /** QueryField **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        public QueryGroup(QueryField queryField) :
            this(queryField?.AsEnumerable(),
                (IEnumerable<QueryGroup>)null,
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        public QueryGroup(QueryField queryField,
            QueryGroup queryGroup) :
            this(queryField?.AsEnumerable(),
                queryGroup?.AsEnumerable(),
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(QueryField queryField,
            Conjunction conjunction) :
            this(queryField?.AsEnumerable(),
                (IEnumerable<QueryGroup>)null,
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                (IEnumerable<QueryGroup>)null,
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            Conjunction conjunction,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                (IEnumerable<QueryGroup>)null,
                conjunction,
                isNot)
        { }

        /** QueryFields **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields) :
            this(queryFields,
                (IEnumerable<QueryGroup>)null,
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            QueryGroup queryGroup) :
            this(queryFields,
                queryGroup?.AsEnumerable(),
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            Conjunction conjunction) :
            this(queryFields,
                (IEnumerable<QueryGroup>)null,
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            bool isNot) :
            this(queryFields,
                (IEnumerable<QueryGroup>)null,
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            Conjunction conjunction,
            bool isNot) :
            this(queryFields,
                (IEnumerable<QueryGroup>)null,
                conjunction,
                isNot)
        { }

        /** QueryGroup **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        public QueryGroup(QueryGroup queryGroup) :
            this((IEnumerable<QueryField>)null,
                queryGroup?.AsEnumerable(),
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(QueryGroup queryGroup,
            Conjunction conjunction) :
            this((IEnumerable<QueryField>)null,
                queryGroup?.AsEnumerable(),
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryGroup queryGroup,
            bool isNot) :
            this((IEnumerable<QueryField>)null,
                queryGroup?.AsEnumerable(),
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryGroup queryGroup,
            Conjunction conjunction,
            bool isNot) :
            this((IEnumerable<QueryField>)null,
                queryGroup?.AsEnumerable(),
                conjunction,
                isNot)
        { }

        /** QueryGroups **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        public QueryGroup(IEnumerable<QueryGroup> queryGroups) :
            this((IEnumerable<QueryField>)null,
                queryGroups,
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(IEnumerable<QueryGroup> queryGroups,
            Conjunction conjunction) :
            this((IEnumerable<QueryField>)null,
                queryGroups,
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryGroup> queryGroups,
            bool isNot) :
            this((IEnumerable<QueryField>)null,
                queryGroups,
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryGroup> queryGroups,
            Conjunction conjunction,
            bool isNot) :
            this((IEnumerable<QueryField>)null,
                queryGroups,
                conjunction,
                isNot)
        { }

        /** QueryField / QueryGroup **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(QueryField queryField,
            QueryGroup queryGroup,
            Conjunction conjunction) :
            this(queryField?.AsEnumerable(),
                queryGroup?.AsEnumerable(),
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            QueryGroup queryGroup,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                queryGroup?.AsEnumerable(),
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            QueryGroup queryGroup,
            Conjunction conjunction,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                queryGroup?.AsEnumerable(),
                conjunction,
                isNot)
        { }

        /** QueryField / QueryGroups **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        public QueryGroup(QueryField queryField,
            IEnumerable<QueryGroup> queryGroups) :
            this(queryField?.AsEnumerable(),
                queryGroups,
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(QueryField queryField,
            IEnumerable<QueryGroup> queryGroups,
            Conjunction conjunction) :
            this(queryField?.AsEnumerable(),
                queryGroups,
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            IEnumerable<QueryGroup> queryGroups,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                queryGroups,
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryField">The field to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(QueryField queryField,
            IEnumerable<QueryGroup> queryGroups,
            Conjunction conjunction,
            bool isNot) :
            this(queryField?.AsEnumerable(),
                queryGroups,
                conjunction,
                isNot)
        { }

        ///** QueryFields / QueryGroup **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            QueryGroup queryGroup,
            Conjunction conjunction) :
            this(queryFields,
                queryGroup?.AsEnumerable(),
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            QueryGroup queryGroup,
            bool isNot) :
            this(queryFields,
                queryGroup?.AsEnumerable(),
                Conjunction.And,
                isNot)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroup">The child query group to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            QueryGroup queryGroup,
            Conjunction conjunction,
            bool isNot) :
            this(queryFields,
                queryGroup?.AsEnumerable(),
                conjunction,
                isNot)
        { }

        /** QueryFields / QueryGroups **/

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            IEnumerable<QueryGroup> queryGroups) :
            this(queryFields,
                queryGroups,
                Conjunction.And,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="conjunction">The conjunction to be used for every group separation.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            IEnumerable<QueryGroup> queryGroups,
            Conjunction conjunction) :
            this(queryFields,
                queryGroups,
                conjunction,
isNot: false)
        { }

        /// <summary>
        /// Creates a new instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="queryFields">The list of fields to be grouped for the query expression.</param>
        /// <param name="queryGroups">The child query groups to be grouped for the query expression.</param>
        /// <param name="isNot">The prefix to be added whether the field value is in opposite state.</param>
        public QueryGroup(IEnumerable<QueryField> queryFields,
            IEnumerable<QueryGroup> queryGroups,
            bool isNot) :
            this(queryFields,
                queryGroups,
                Conjunction.And,
                isNot)
        { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the conjunction used by this object.
        /// </summary>
        public Conjunction Conjunction { get; } = conjunction;

        /// <summary>
        /// Gets the list of child <see cref="QueryField"/> objects.
        /// </summary>
        public IReadOnlyList<QueryField> QueryFields { get; } = queryFields?.AsList();

        /// <summary>
        /// Gets the list of child <see cref="QueryGroup"/> objects.
        /// </summary>
        public IReadOnlyList<QueryGroup> QueryGroups { get; } = queryGroups.AsList();

        /// <summary>
        /// Gets the value whether the grouping is in opposite field-value state.
        /// </summary>
        public bool IsNot { get; private set; } = isNot;

        #endregion

        #region Methods (Internal)

        /// <summary>
        /// 
        /// </summary>
        /// <param name="prefix"></param>
        internal void PrependTextToAllParameters(string prefix)
        {
            var traversedFields = GetFields(traverse: true);
            if (traversedFields?.Any() != true)
            {
                return;
            }
            foreach (var queryField in traversedFields)
            {
                queryField.PrependTextToParameter(prefix);
            }
        }

        /// <summary>
        /// Sets the value of the <see cref="IsNot"/> property.
        /// </summary>
        /// <param name="value">The <see cref="bool"/> value the defines the <see cref="IsNot"/> property.</param>
        internal void SetIsNot(bool value)
        {
            IsNot = value;
        }

        /// <summary>
        /// Fix the names of the parameters in every <see cref="QueryField"/> object of the target list of <see cref="QueryGroup"/>s.
        /// </summary>
        /// <param name="queryGroups">The list of query groups.</param>
        internal static void FixForQueryMultiple(QueryGroup[] queryGroups)
        {
            for (var i = 0; i < queryGroups.Length; i++)
            {
                var fields = queryGroups[i]?.GetFields(traverse: true);

                if (fields?.Any() == true)
                {
                    foreach (var field in fields)
                    {
                        field.Parameter.SetName(string.Format(System.Globalization.CultureInfo.InvariantCulture, "T{0}_{1}", i, field.Parameter.Name));
                    }
                }
            }
        }

        /// <summary>
        /// Forces to set the <see cref="isFixed"/> variable to True.
        /// </summary>
        private void ForceIsFixedVariables()
        {
            if (QueryGroups?.Count > 0)
            {
                foreach (var queryGroup in QueryGroups)
                {
                    queryGroup.ForceIsFixedVariables();
                }
            }
            isFixed = true;
        }

        /// <summary>
        /// Reset all the query fields.
        /// </summary>
        private void ResetQueryFields()
        {
            if (QueryFields?.Any() != true)
            {
                return;
            }
            foreach (var field in QueryFields)
            {
                field.Reset();
            }
        }

        /// <summary>
        /// Reset all the query groups.
        /// </summary>
        private void ResetQueryGroups()
        {
            if (QueryGroups is null || QueryGroups.Count == 0)
            {
                return;
            }
            foreach (var group in QueryGroups)
            {
                group.Reset();
            }
        }

        /// <summary>
        /// Fix the query fields names.
        /// </summary>
        /// <param name="fields"></param>
        private static void FixQueryFields(IEnumerable<QueryField> fields)
        {
            var firstList = fields
                .OrderBy(queryField => queryField.Parameter.Name, StringComparer.OrdinalIgnoreCase)
                .AsList();
            var secondList = new List<QueryField>(firstList);

            foreach (var firstQueryField in firstList)
            {
                for (var fieldIndex = 0; fieldIndex < secondList.Count; fieldIndex++)
                {
                    var secondQueryField = secondList[fieldIndex];
                    if (ReferenceEquals(firstQueryField, secondQueryField))
                    {
                        continue;
                    }
                    if (firstQueryField.Field.Equals(secondQueryField.Field))
                    {
                        var fieldValue = secondQueryField.Parameter;
                        fieldValue.SetName(string.Concat(secondQueryField.Parameter.Name, "_", fieldIndex.ToString(System.Globalization.CultureInfo.InvariantCulture)));
                    }
                }
                secondList.RemoveAll(qf => qf.Field.Equals(firstQueryField.Field));
            }
        }

        #endregion

        #region Methods (Public)

        /// <summary>
        /// Reset the <see cref="QueryGroup"/> back to its default state (as is newly instantiated).
        /// </summary>
        public void Reset()
        {
            ResetQueryFields();
            ResetQueryGroups();
            isFixed = false;
            hashCode = null;
        }

        /// <summary>
        /// Fix the names of the <see cref="Parameter"/> on every <see cref="QueryField"/> (and on every child <see cref="QueryGroup"/>) of the current <see cref="QueryGroup"/>.
        /// </summary>
        /// <returns>The current instance.</returns>
        public QueryGroup Fix()
        {
            if (isFixed)
            {
                return this;
            }

            // Check the presence
            var fields = GetFields(traverse: true);

            // Check any item
            if (fields?.Any() != true)
            {
                return this;
            }

            // Fix the fields
            FixQueryFields(fields);

            // Force the variables
            ForceIsFixedVariables();

            // Return the current instance
            return this;
        }

        /// <summary>
        /// Make the current instance of <see cref="QueryGroup"/> object to become an expression for 'Update' operations.
        /// </summary>
        public void IsForUpdate()
        {
            PrependTextToAllParameters(StringConstant.UpdateParameterPrefix);
        }


        /// <summary>
        /// Gets the stringified query expression format of the current instance. A formatted string for field-operation-parameter will be
        /// conjuncted by the value of the <see cref="Conjunction"/> property.
        /// </summary>
        /// <param name="dbSetting">The currently in used <see cref="IDbSetting"/> object.</param>
        /// <returns>A stringified formatted-text of the current instance.</returns>
        public virtual string GetString(IDbSetting dbSetting)
        {
            return GetString(0, dbSetting);
        }

        /// <summary>
        /// Gets the stringified query expression format of the current instance. A formatted string for field-operation-parameter will be
        /// conjuncted by the value of the <see cref="RepoDb.Enumerations.Conjunction"/> property.
        /// </summary>
        /// <param name="index">The parameter index for batch operation.</param>
        /// <param name="dbSetting">The currently in used <see cref="IDbSetting"/> object.</param>
        /// <returns>A stringified formatted-text of the current instance.</returns>
        public string GetString(int index,
            IDbSetting dbSetting)
        {
            // Fix first the parameters
            Fix();

            // Variables
            var groupList = new List<string>();
            var conjunctionText = Conjunction.GetText();
            var separator = string.Concat(" ", conjunctionText, " ");

            // Check the instance fields
            if (QueryFields?.Count > 0)
            {
                var fields = QueryFields
                    .Select(qf =>
                        qf.GetString(index, dbSetting)).Join(separator);
                groupList.Add(fields);
            }

            // Check the instance groups
            if (QueryGroups?.Count > 0)
            {
                var groups = QueryGroups
                    .Select(qg =>
                        qg.GetString(index, dbSetting)).Join(separator);
                groupList.Add(groups);
            }

            // Return the value
            return IsNot ? string.Concat("NOT (", groupList.Join(conjunctionText), ")") : string.Concat("(", groupList.Join(separator), ")");
        }

        /// <summary>
        /// Gets all the child <see cref="QueryField"/> objects associated on the current instance.
        /// </summary>
        /// <param name="traverse">Identify whether to explore all the children of the child <see cref="QueryGroup"/> objects.</param>
        /// <returns>An enumerable list of <see cref="QueryField"/> objects.</returns>
        public IEnumerable<QueryField> GetFields(bool traverse)
        {
            if (!traverse)
            {
                return QueryFields;
            }

            if (traversedQueryFields is not null)
            {
                return traversedQueryFields;
            }

            // Variables
            var explore = (Action<QueryGroup>)null;
            var items = new List<QueryField>();

            // Logic for traverse
            explore = queryGroup =>
            {
                // Check child fields
                if (queryGroup.QueryFields?.Count > 0)
                {
                    items.AddRange(queryGroup.QueryFields);
                }

                // Check child groups
                if (queryGroup.QueryGroups?.Count > 0)
                {
                    foreach (var qg in queryGroup.QueryGroups)
                    {
                        explore(qg);
                    }
                }
            };

            // Explore
            explore(this);

            // Return the value
            return traversedQueryFields = items;
        }

        #endregion

        #region Equality and comparers

        /// <summary>
        /// Returns the hashcode for this <see cref="QueryGroup"/>.
        /// </summary>
        /// <returns>The hashcode value.</returns>
        public override int GetHashCode()
        {
            // Make sure to check if this is already taken
            if (this.hashCode != null)
            {
                return this.hashCode.Value;
            }

            var computedHashCode = 0;

            // Iterates the child query field
            if (QueryFields != null)
            {
                foreach (var queryField in QueryFields)
                {
                    computedHashCode = HashCode.Combine(computedHashCode, queryField);
                }
            }

            // Iterates the child query groups
            if (QueryGroups?.Count > 0)
            {
                foreach (var queryGroup in QueryGroups)
                {
                    computedHashCode = HashCode.Combine(computedHashCode, queryGroup);
                }
            }

            // Set with conjunction
            computedHashCode = HashCode.Combine(computedHashCode, Conjunction);

            // Set the IsNot
            computedHashCode = HashCode.Combine(computedHashCode, IsNot);

            // Set and return the hashcode
            return (this.hashCode = computedHashCode).Value;
        }

        /// <summary>
        /// Compares the <see cref="QueryGroup"/> object equality against the given target object.
        /// </summary>
        /// <param name="obj">The object to be compared to the current object.</param>
        /// <returns>True if the instances are equals.</returns>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;

            return obj.GetHashCode() == GetHashCode();
        }

        /// <summary>
        /// Compares the <see cref="QueryGroup"/> object equality against the given target object.
        /// </summary>
        /// <param name="other">The object to be compared to the current object.</param>
        /// <returns>True if the instances are equal.</returns>
        public bool Equals(QueryGroup other)
        {
            if (other is null) return false;

            return other.GetHashCode() == GetHashCode();
        }

        /// <summary>
        /// Compares the equality of the two <see cref="QueryGroup"/> objects.
        /// </summary>
        /// <param name="objA">The first <see cref="QueryGroup"/> object.</param>
        /// <param name="objB">The second <see cref="QueryGroup"/> object.</param>
        /// <returns>True if the instances are equal.</returns>
        public static bool operator ==(QueryGroup objA,
            QueryGroup objB)
        {
            if (objA is null)
            {
                return objB is null;
            }
            return objA.Equals(objB);
        }

        /// <summary>
        /// Compares the inequality of the two <see cref="QueryGroup"/> objects.
        /// </summary>
        /// <param name="objA">The first <see cref="QueryGroup"/> object.</param>
        /// <param name="objB">The second <see cref="QueryGroup"/> object.</param>
        /// <returns>True if the instances are not equal.</returns>
        public static bool operator !=(QueryGroup objA,
            QueryGroup objB) => !(objA == objB);

        #endregion
    }
}
