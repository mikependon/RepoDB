﻿#region Copyright Attributions

// Copyright (c) 2020 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RepoDb
{
    public partial class QueryGroup
    {
        /// <summary>
        /// Parses an object and convert back the result to an instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="obj">The instance of the object to be parsed.</param>
        /// <returns>An instance of the <see cref="QueryGroup"/> with parsed properties and values.</returns>
        public static QueryGroup Parse<T>(T obj)
        {
            return Parse<T>(obj, throwException: true);
        }

        /// <summary>
        /// Parses an object and convert back the result to an instance of <see cref="QueryGroup"/> object.
        /// </summary>
        /// <param name="obj">The instance of the object to be parsed.</param>
        /// <param name="throwException">If true, an exception will be thrown if the type of 'obj' argument cannot be parsed.</param>
        /// <returns>An instance of the <see cref="QueryGroup"/> with parsed properties and values.</returns>
        public static QueryGroup Parse<T>(T obj,
            bool throwException = true)
        {
            // Check for value
            if (obj == null)
            {
                throw new ArgumentNullException(nameof(obj));
            }

            // Type of the object
            var type = TypeCache.Get(obj.GetType()).GetUnderlyingType();

            // Filter the type
            if (!TypeCache.Get(type).IsClassType())
            {
                if (throwException)
                {
                    throw new ArgumentException("Parameter 'obj' type cannot be parsed.", nameof(obj));
                }
                else
                {
                    return null;
                }
            }

            // Declare variables
            var properties = TypeCache.Get(type).GetProperties();
            var queryFields = new List<QueryField>(properties.Length);

            // Iterate every property
            foreach (var property in properties)
            {
                queryFields.Add(
                    new QueryField(property.AsField(), Enumerations.Operation.Equal, property.GetValue(obj), dbType: null));
            }

            // Return
            return queryFields.Any() ? new QueryGroup(queryFields).Fix() : null;
        }
    }
}
