﻿#region Copyright Attributions

// Copyright (c) 2019 Michael Camara Pendon.
// Portions copyright their respective RepoDB contributors.
// Licensed under the Apache License, Version 2.0.
// See the LICENSE file in the project root for full license information.

#endregion

using RepoDb.Extensions;
using RepoDb.Interfaces;
using System;

namespace RepoDb.Resolvers
{
    /// <summary>
    /// A class that is being used to resolve the .NET CLR type into its averageable .NET CLR type.
    /// </summary>
    public class ClientTypeToAverageableClientTypeResolver : IResolver<Type, Type>
    {
        /// <summary>
        /// Returns the averageable .NET CLR type.
        /// </summary>
        /// <param name="type">The .NET CLR type.</param>
        /// <returns>The averageable .NET CLR type.</returns>
        public Type Resolve(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException(nameof(type), "The type must not be null.");
            }

            // Get the type
            type = TypeCache.Get(type).GetUnderlyingType();

            // Only convert those numerics
            if (type == StaticType.Int16 ||
               type == StaticType.Int32 ||
               type == StaticType.Int64 ||
               type == StaticType.UInt16 ||
               type == StaticType.UInt32 ||
               type == StaticType.UInt64)
            {
                type = StaticType.Double;
            }

            // Return the type
            return type;
        }
    }
}
